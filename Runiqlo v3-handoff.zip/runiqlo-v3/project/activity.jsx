/* RUNIQLO — Activities list + detail. Babel/JSX. Exports to window. */

function ActivitiesScreen({ route, onNav, onOpenActivity }) {
  if (route.activityId) {
    const act = window.R.activities.find((a) => a.id === route.activityId);
    return <ActivityDetail act={act} onBack={() => onNav({ screen: "activities" })} onNav={onNav} />;
  }
  return <ActivityList onOpen={onOpenActivity} />;
}

/* ---------------- list ---------------- */
function ActivityList({ onOpen }) {
  const [filter, setFilter] = useState("all");
  const acts = window.R.activities;
  const filtered = filter === "all" ? acts : acts.filter((a) => a.type === filter);
  const total = acts.reduce((s, a) => s + a.dist, 0);
  const totalTime = acts.reduce((s, a) => s + a.durMin, 0);
  const filters = [["all", "ALL"], ["long", "LONG"], ["threshold", "THRESHOLD"], ["interval", "INTERVAL"], ["easy", "EASY"]];
  return (
    <div className="rise" style={{ display: "flex", flexDirection: "column", gap: "var(--gap)" }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: "var(--gap)" }}>
        {[
          { label: "ACTIVITIES · 28d", value: acts.length, unit: "runs" },
          { label: "VOLUME", value: total.toFixed(0), unit: "km" },
          { label: "MOVING TIME", value: (totalTime / 60).toFixed(1), unit: "h" },
          { label: "PLAN ADHERENCE", value: Math.round(acts.filter(a => a.adherence === "match").length / acts.length * 100), unit: "%", color: "var(--fresh)" },
        ].map((m, i) => (
          <Tile key={i} pad>
            <Readout label={m.label} value={m.value} unit={m.unit} color={m.color} size="var(--fs-xl)" />
          </Tile>
        ))}
      </div>
      <Tile title="Activity Log" pad={false} ticks
        right={
          <div style={{ display: "flex", gap: 3 }}>
            {filters.map(([id, lb]) => (
              <button key={id} onClick={() => setFilter(id)} style={{ padding: "5px 10px", borderRadius: 6, border: "1px solid " + (filter === id ? "var(--line-2)" : "transparent"),
                background: filter === id ? "var(--panel-3)" : "transparent", color: filter === id ? "var(--text)" : "var(--faint)", cursor: "pointer",
                fontFamily: "var(--mono)", fontSize: 10, letterSpacing: "0.08em" }}>{lb}</button>
            ))}
          </div>
        }>
        <div style={{ padding: "4px var(--pad) 8px" }}>
          {filtered.map((a) => (
            <ActivityRow key={a.id} act={a} onClick={() => onOpen(a.id)} />
          ))}
        </div>
      </Tile>
    </div>
  );
}

/* ---------------- detail ---------------- */
function ActivityDetail({ act, onBack, onNav }) {
  const zones = window.R.athlete.zones;
  const [stream, setStream] = useState("hr");
  // km splits derived from pace stream
  const splits = [];
  const perKm = Math.floor(act.streams.pace.length / act.dist);
  for (let k = 0; k < Math.floor(act.dist); k++) {
    const chunk = act.streams.pace.slice(k * perKm, (k + 1) * perKm);
    const avg = chunk.reduce((a, b) => a + b, 0) / chunk.length;
    splits.push(Math.round(avg));
  }
  const fastest = Math.min(...splits), slowest = Math.max(...splits);
  const wk = window.WORKOUT[act.type];
  const streamCfg = {
    hr: { data: act.streams.hr, color: "var(--z5)", label: "HEART RATE", unit: "bpm", bands: true, yMin: 100, yMax: 195 },
    pace: { data: act.streams.pace.map(p => 600 - p), color: "var(--accent)", label: "PACE", unit: "/km", bands: false, raw: act.streams.pace },
    elev: { data: act.streams.elev, color: "var(--z2)", label: "ELEVATION", unit: "m", bands: false },
  }[stream];

  return (
    <div className="rise" style={{ display: "flex", flexDirection: "column", gap: "var(--gap)" }}>
      {/* header */}
      <div style={{ display: "flex", alignItems: "center", gap: 14, flexWrap: "wrap" }}>
        <button className="btn btn-ghost" onClick={onBack}><Icon name="arrow" size={14} style={{ transform: "rotate(180deg)" }} /> Log</button>
        <span style={{ width: 1, height: 26, background: "var(--line)" }} />
        <span style={{ width: 34, height: 34, borderRadius: 8, border: "1px solid " + wk.color, display: "grid", placeItems: "center",
          background: "color-mix(in srgb, " + wk.color + " 12%, transparent)" }}><WorkoutDot type={act.type} size={11} /></span>
        <div>
          <div style={{ fontSize: "var(--fs-lg)", fontWeight: 600 }}>{act.name}</div>
          <div className="lbl" style={{ marginTop: 2 }}>{fmtDate(act.date, { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })} · {window.R.athlete.location.toUpperCase()}</div>
        </div>
        <div style={{ flex: 1 }} />
        <AdherenceBadge a={act.adherence} />
        <button className="btn" onClick={() => onNav({ screen: "coach" })}><Icon name="coach" size={13} /> Discuss</button>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "minmax(0,1.9fr) minmax(280px,1fr)", gap: "var(--gap)", alignItems: "start" }}>
        {/* left */}
        <div style={{ display: "flex", flexDirection: "column", gap: "var(--gap)" }}>
          <Tile title="Route" pad={false}>
            <div style={{ position: "relative" }}>
              <RouteTrace d={act.routeD} height={300} />
              <div style={{ position: "absolute", left: 14, bottom: 14, display: "flex", gap: 18, background: "color-mix(in srgb, var(--bg) 78%, transparent)",
                backdropFilter: "blur(6px)", padding: "10px 16px", borderRadius: 9, border: "1px solid var(--line)" }}>
                {[[act.dist.toFixed(2), "km"], [act.dur, "time"], [act.pace, "/km"], ["+" + act.elev, "m"]].map(([v, u], i) => (
                  <div key={i} style={{ display: "flex", flexDirection: "column" }}>
                    <span className="num" style={{ fontSize: 18, fontWeight: 600 }}>{v}</span>
                    <span className="lbl" style={{ fontSize: 8.5 }}>{u}</span>
                  </div>
                ))}
              </div>
            </div>
          </Tile>

          <Tile title="Streams" right={
            <div style={{ display: "flex", gap: 3 }}>
              {[["hr", "HR"], ["pace", "PACE"], ["elev", "ELEV"]].map(([id, lb]) => (
                <button key={id} onClick={() => setStream(id)} style={{ padding: "4px 10px", borderRadius: 6, border: "1px solid " + (stream === id ? "var(--line-2)" : "transparent"),
                  background: stream === id ? "var(--panel-3)" : "transparent", color: stream === id ? "var(--text)" : "var(--faint)", cursor: "pointer",
                  fontFamily: "var(--mono)", fontSize: 10, letterSpacing: "0.06em" }}>{lb}</button>
              ))}
            </div>
          }>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
              <span className="lbl" style={{ color: streamCfg.color }}>{streamCfg.label}</span>
              <span className="mono" style={{ fontSize: 11, color: "var(--dim)" }}>
                {stream === "hr" && `AVG ${act.avgHr} · MAX ${act.maxHr} BPM`}
                {stream === "pace" && `AVG ${act.pace} /KM`}
                {stream === "elev" && `+${act.elev} M GAIN`}
              </span>
            </div>
            <StreamChart stream={streamCfg.data} zones={stream === "hr" ? zones : null} bands={streamCfg.bands}
              color={streamCfg.color} height={170} yMin={streamCfg.yMin} yMax={streamCfg.yMax} />
          </Tile>

          <Tile title="Splits" right={<span className="lbl">PER KM</span>}>
            <div style={{ display: "flex", alignItems: "flex-end", gap: 3, height: 110 }}>
              {splits.map((p, i) => {
                const t = (p - fastest) / (slowest - fastest || 1);
                const h = 30 + (1 - t) * 64;
                const isFast = p === fastest;
                return (
                  <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4, height: "100%", justifyContent: "flex-end" }}
                    title={`KM ${i + 1} · ${window.R.helpers.fmtPace(p)}/km`}>
                    <div style={{ width: "100%", height: h + "%", background: isFast ? "var(--accent)" : "var(--panel-3)", border: "1px solid " + (isFast ? "var(--accent)" : "var(--line-2)"),
                      borderRadius: "3px 3px 0 0" }} />
                    <span className="mono" style={{ fontSize: 8.5, color: "var(--faint)" }}>{i + 1}</span>
                  </div>
                );
              })}
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8 }}>
              <span className="lbl">FASTEST {window.R.helpers.fmtPace(fastest)}</span>
              <span className="lbl">SLOWEST {window.R.helpers.fmtPace(slowest)}</span>
            </div>
          </Tile>
        </div>

        {/* right */}
        <div style={{ display: "flex", flexDirection: "column", gap: "var(--gap)" }}>
          <Tile title="Plan Adherence" ticks>
            <PlanAdherence act={act} />
          </Tile>
          <Tile title="Metrics">
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 1, background: "var(--line)", border: "1px solid var(--line)", borderRadius: 8, overflow: "hidden" }}>
              {[
                ["DISTANCE", act.dist.toFixed(2), "km"], ["MOVING", act.dur, ""],
                ["AVG PACE", act.pace, "/km"], ["AVG HR", act.avgHr, "bpm"],
                ["MAX HR", act.maxHr, "bpm"], ["ELEV GAIN", "+" + act.elev, "m"],
                ["TRAIN LOAD", act.tss, "tss"], ["EST. kCAL", Math.round(act.durMin * 13.5), ""],
              ].map(([k, v, u], i) => (
                <div key={i} style={{ background: "var(--panel)", padding: "11px 13px" }}>
                  <div className="lbl" style={{ fontSize: 8.5 }}>{k}</div>
                  <div style={{ display: "flex", alignItems: "baseline", gap: 3, marginTop: 3 }}>
                    <span className="num" style={{ fontSize: 17, fontWeight: 600 }}>{v}</span>
                    {u && <span className="mono" style={{ fontSize: 9.5, color: "var(--faint)" }}>{u}</span>}
                  </div>
                </div>
              ))}
            </div>
          </Tile>
          <Tile title="HR Zone Breakdown">
            <ZoneStack zones={zones} dist={act.zones} height={12} showPct={false} />
            <div style={{ marginTop: 14, display: "flex", flexDirection: "column", gap: 9 }}>
              {zones.map((z, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <span style={{ width: 9, height: 9, borderRadius: 2, background: z.color }} />
                  <span className="mono" style={{ fontSize: 10.5, width: 22, color: "var(--dim)" }}>Z{z.z}</span>
                  <span className="lbl" style={{ flex: 1 }}>{z.name}</span>
                  <span className="num" style={{ fontSize: 12, fontWeight: 600 }}>{window.R.helpers.fmtDur(Math.round(act.zones[i] * act.durMin))}</span>
                  <span className="mono" style={{ fontSize: 11, color: "var(--faint)", width: 34, textAlign: "right" }}>{Math.round(act.zones[i] * 100)}%</span>
                </div>
              ))}
            </div>
          </Tile>
        </div>
      </div>
    </div>
  );
}

function PlanAdherence({ act }) {
  const cfg = window.ADHERENCE[act.adherence];
  const match = act.adherence === "match";
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <span style={{ width: 40, height: 40, borderRadius: 9, border: "1px solid " + cfg.color, color: cfg.color,
          display: "grid", placeItems: "center", fontSize: 18 }}>{cfg.dot}</span>
        <div>
          <div className="num" style={{ fontSize: 16, fontWeight: 600, color: cfg.color }}>{cfg.label}</div>
          <div className="lbl" style={{ marginTop: 2 }}>{match ? "EXECUTED AS PRESCRIBED" : act.adherence === "partial" ? "DEVIATED FROM PLAN" : "NOT ON PLAN"}</div>
        </div>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        <div style={{ display: "flex", justifyContent: "space-between", padding: "9px 11px", background: "var(--panel-2)", borderRadius: 7, border: "1px solid var(--line)" }}>
          <span className="lbl">PLANNED</span>
          <span className="mono" style={{ fontSize: 11.5, fontWeight: 600 }}>{act.planned}</span>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", padding: "9px 11px", background: "var(--panel-2)", borderRadius: 7, border: "1px solid var(--line)" }}>
          <span className="lbl">COMPLETED</span>
          <span className="mono" style={{ fontSize: 11.5, fontWeight: 600, color: cfg.color }}>{window.WORKOUT[act.type].label} · {act.dist.toFixed(1)} KM · {act.pace}/KM</span>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ActivitiesScreen, ActivityDetail, ActivityList });
