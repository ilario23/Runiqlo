/* RUNIQLO — Segments: list + detail. Babel/JSX. Exports to window. */

function SegmentsScreen({ route, onNav }) {
  if (route.segmentId) {
    const seg = window.R.segments.find((s) => s.id === route.segmentId);
    return <SegmentDetail seg={seg} onBack={() => onNav({ screen: "segments" })} />;
  }
  return <SegmentList onOpen={(id) => onNav({ screen: "segments", segmentId: id })} />;
}

function fmtSecs(s) {
  const m = Math.floor(s / 60), ss = Math.round(s % 60);
  return m + ":" + String(ss).padStart(2, "0");
}
const TREND = {
  up:   { color: "var(--fresh)", glyph: "▲", label: "IMPROVING" },
  flat: { color: "var(--neutral)", glyph: "▬", label: "STEADY" },
  down: { color: "var(--fatigue)", glyph: "▼", label: "SLIPPING" },
};

function SegmentList({ onOpen }) {
  const [sort, setSort] = useState("attempts");
  const segs = [...window.R.segments].sort((a, b) =>
    sort === "attempts" ? b.attempts - a.attempts : sort === "trend" ? (b.trend === "up") - (a.trend === "up") : a.efforts[a.efforts.length - 1] - b.efforts[b.efforts.length - 1]
  );
  const sorts = [["attempts", "MOST RUN"], ["trend", "TRENDING"], ["pr", "FASTEST"]];
  const totalAttempts = window.R.segments.reduce((s, x) => s + x.attempts, 0);
  const prs = window.R.segments.filter((s) => {
    const last = s.efforts[s.efforts.length - 1];
    return last === Math.min(...s.efforts);
  }).length;

  return (
    <div className="rise" style={{ display: "flex", flexDirection: "column", gap: "var(--gap)" }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: "var(--gap)" }}>
        {[
          { label: "TRACKED SEGMENTS", value: window.R.segments.length, unit: "" },
          { label: "TOTAL EFFORTS", value: totalAttempts, unit: "" },
          { label: "CURRENT PRs", value: prs, unit: "held", color: "var(--accent)" },
          { label: "IMPROVING", value: window.R.segments.filter(s => s.trend === "up").length, unit: "of " + window.R.segments.length, color: "var(--fresh)" },
        ].map((m, i) => (
          <Tile key={i} pad><Readout label={m.label} value={m.value} unit={m.unit} color={m.color} size="var(--fs-xl)" /></Tile>
        ))}
      </div>
      <Tile title="Segments" pad={false}
        right={
          <div style={{ display: "flex", gap: 3 }}>
            {sorts.map(([id, lb]) => (
              <button key={id} onClick={() => setSort(id)} style={{ padding: "5px 11px", borderRadius: 8, border: "none",
                background: sort === id ? "var(--panel-3)" : "transparent", color: sort === id ? "var(--text)" : "var(--faint)", cursor: "pointer",
                fontFamily: "var(--sans)", fontSize: 11, fontWeight: 600, letterSpacing: "0.03em" }}>{lb}</button>
            ))}
          </div>
        }>
        <div style={{ padding: "4px var(--pad) 10px" }}>
          {segs.map((s) => {
            const last = s.efforts[s.efforts.length - 1];
            const first = s.efforts[0];
            const tr = TREND[s.trend];
            const isPr = last === Math.min(...s.efforts);
            return (
              <button key={s.id} onClick={() => onOpen(s.id)} style={{ display: "grid",
                gridTemplateColumns: "auto 1fr auto auto auto", alignItems: "center", gap: 16, width: "100%", textAlign: "left",
                background: "transparent", border: "none", borderBottom: "1px solid var(--line)", padding: "13px 4px", cursor: "pointer", color: "inherit", transition: "background .12s" }}
                onMouseEnter={(e) => e.currentTarget.style.background = "var(--panel-2)"}
                onMouseLeave={(e) => e.currentTarget.style.background = "transparent"}>
                <div style={{ width: 56, height: 36, borderRadius: 8, overflow: "hidden", border: "1px solid var(--line)", flexShrink: 0 }}>
                  <MiniTrace d={s.routeD} />
                </div>
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontSize: 13.5, fontWeight: 590, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", display: "flex", alignItems: "center", gap: 7 }}>
                    {s.name}{isPr && <span className="tag" style={{ color: "var(--accent)", borderColor: "color-mix(in srgb, var(--accent) 40%, transparent)", padding: "1px 7px" }}>PR</span>}
                  </div>
                  <div className="lbl" style={{ marginTop: 3 }}>{(s.dist / 1000).toFixed(2)} KM · {s.grade > 0 ? "+" : ""}{s.grade}% GRADE</div>
                </div>
                <div style={{ width: 88, height: 30 }}><Sparkline data={s.efforts.map(e => -e)} width={88} height={30} color={tr.color} /></div>
                <Mini v={fmtSecs(last)} u="last" />
                <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", minWidth: 64 }}>
                  <span className="num" style={{ fontSize: 14, fontWeight: 650, color: "var(--accent)" }}>{s.pr}</span>
                  <span className="lbl" style={{ fontSize: 8.5 }}>{s.attempts} efforts</span>
                </div>
              </button>
            );
          })}
        </div>
      </Tile>
    </div>
  );
}

function MiniTrace({ d }) {
  return (
    <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet" style={{ display: "block" }}>
      <path d={d} fill="none" stroke="var(--accent)" strokeWidth="3" strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}

function SegmentDetail({ seg, onBack }) {
  const tr = TREND[seg.trend];
  const efforts = seg.efforts;
  const best = Math.min(...efforts);
  const worst = Math.max(...efforts);
  const last = efforts[efforts.length - 1];
  const first = efforts[0];
  const deltaPct = (((first - last) / first) * 100).toFixed(1);
  // build an effort-history table (most recent first), synthetic dates
  const rows = efforts.map((e, i) => ({
    n: efforts.length - i,
    secs: e,
    isPr: e === best,
    date: new Date(window.R.TODAY.getTime() - (efforts.length - 1 - i) * 11 * 86400000),
  })).reverse();

  return (
    <div className="rise" style={{ display: "flex", flexDirection: "column", gap: "var(--gap)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 14, flexWrap: "wrap" }}>
        <button className="btn btn-ghost" onClick={onBack}><Icon name="arrow" size={14} style={{ transform: "rotate(180deg)" }} /> Segments</button>
        <span style={{ width: 1, height: 26, background: "var(--line)" }} />
        <div>
          <div style={{ fontSize: "var(--fs-lg)", fontWeight: 650, letterSpacing: "-0.015em" }}>{seg.name}</div>
          <div className="lbl" style={{ marginTop: 2 }}>{(seg.dist / 1000).toFixed(2)} KM · {seg.grade > 0 ? "+" : ""}{seg.grade}% GRADE · {seg.attempts} EFFORTS</div>
        </div>
        <div style={{ flex: 1 }} />
        <Tag color={tr.color}><span style={{ fontSize: 9 }}>{tr.glyph}</span> {tr.label}</Tag>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "minmax(0,1.9fr) minmax(280px,1fr)", gap: "var(--gap)", alignItems: "start" }}>
        <div style={{ display: "flex", flexDirection: "column", gap: "var(--gap)" }}>
          <Tile title="Effort History" right={<span className="lbl">{seg.attempts} EFFORTS · SECONDS</span>}>
            <EffortChart efforts={efforts} best={best} height={210} />
          </Tile>
          <Tile title="All Efforts" pad={false}>
            <div className="scroll" style={{ maxHeight: 280, padding: "4px var(--pad) 10px" }}>
              {rows.map((r, i) => {
                const pct = (r.secs - best) / (worst - best || 1);
                return (
                  <div key={i} style={{ display: "grid", gridTemplateColumns: "auto 1fr auto auto", alignItems: "center", gap: 14,
                    padding: "9px 2px", borderBottom: i < rows.length - 1 ? "1px solid var(--line)" : "none" }}>
                    <span className="lbl" style={{ width: 28 }}>#{r.n}</span>
                    <div style={{ height: 6, background: "var(--panel-3)", borderRadius: 4, overflow: "hidden" }}>
                      <div style={{ width: (100 - pct * 70) + "%", height: "100%", background: r.isPr ? "var(--accent)" : "var(--line-3)", borderRadius: 4 }} />
                    </div>
                    {r.isPr ? <Tag color="var(--accent)" style={{ padding: "1px 7px" }}>PR</Tag> : <span style={{ width: 30 }} />}
                    <span className="num" style={{ fontSize: 13.5, fontWeight: 600, color: r.isPr ? "var(--accent)" : "var(--text)", width: 70, textAlign: "right" }}>
                      {fmtSecs(r.secs)} <span className="lbl" style={{ fontSize: 8 }}>{fmtDate(r.date)}</span>
                    </span>
                  </div>
                );
              })}
            </div>
          </Tile>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: "var(--gap)" }}>
          <Tile title="Personal Record" ticks>
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              <div>
                <div className="num" style={{ fontSize: "var(--fs-hero)", fontWeight: 680, color: "var(--accent)", letterSpacing: "-0.04em", lineHeight: 1 }}>{seg.pr}</div>
                <div className="lbl" style={{ marginTop: 5 }}>SET {fmtDate(seg.prDate, { month: "long", day: "numeric", year: "numeric" }).toUpperCase()}</div>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 1, background: "var(--line)", border: "1px solid var(--line)", borderRadius: "var(--radius-sm)", overflow: "hidden" }}>
                {[
                  ["LAST EFFORT", fmtSecs(last)],
                  ["AVG EFFORT", fmtSecs(Math.round(efforts.reduce((a, b) => a + b, 0) / efforts.length))],
                  ["VS PR", "+" + fmtSecs(last - best)],
                  ["GAINED", deltaPct + "%", "var(--fresh)"],
                ].map(([k, v, c], i) => (
                  <div key={i} style={{ background: "var(--panel)", padding: "11px 13px" }}>
                    <div className="lbl" style={{ fontSize: 8.5 }}>{k}</div>
                    <div className="num" style={{ fontSize: 17, fontWeight: 600, marginTop: 3, color: c || "var(--text)" }}>{v}</div>
                  </div>
                ))}
              </div>
            </div>
          </Tile>
          <Tile title="Course" pad={false}>
            <RouteTrace d={seg.routeD} height={180} />
          </Tile>
          <Tile title="Estimated Pace">
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
              <Readout label="AT PR" value={fmtSecs(Math.round((best / (seg.dist / 1000))))} unit="/km" size="var(--fs-xl)" color="var(--accent)" />
              <Readout label="LAST EFFORT" value={fmtSecs(Math.round((last / (seg.dist / 1000))))} unit="/km" size="var(--fs-xl)" />
            </div>
          </Tile>
        </div>
      </div>
    </div>
  );
}

function EffortChart({ efforts, best, height = 200 }) {
  const [ref, { w }] = useMeasure();
  const [hover, setHover] = useState(null);
  const padL = 34, padR = 14, padT = 14, padB = 22;
  const innerW = Math.max(10, w - padL - padR), innerH = height - padT - padB;
  const lo = Math.min(...efforts) * 0.985, hi = Math.max(...efforts) * 1.015;
  const x = (i) => padL + (i / (efforts.length - 1)) * innerW;
  const y = (v) => padT + ((v - lo) / (hi - lo)) * innerH; // lower secs = higher (better)
  const line = "M" + efforts.map((v, i) => `${x(i)},${y(v)}`).join(" L");
  const area = `M${padL},${padT + innerH} L` + efforts.map((v, i) => `${x(i)},${y(v)}`).join(" L") + ` L${padL + innerW},${padT + innerH} Z`;
  const bestI = efforts.indexOf(best);
  const onMove = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    let i = Math.round(((e.clientX - rect.left - padL) / innerW) * (efforts.length - 1));
    setHover(Math.max(0, Math.min(efforts.length - 1, i)));
  };
  return (
    <div ref={ref} style={{ width: "100%", height, position: "relative" }}>
      {w > 0 && (
        <svg width={w} height={height} onMouseMove={onMove} onMouseLeave={() => setHover(null)} style={{ display: "block" }}>
          <defs>
            <linearGradient id="effGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="var(--accent)" stopOpacity="0.18" />
              <stop offset="100%" stopColor="var(--accent)" stopOpacity="0.01" />
            </linearGradient>
          </defs>
          {[0, 0.5, 1].map((t, k) => (
            <line key={k} x1={padL} x2={padL + innerW} y1={padT + innerH * t} y2={padT + innerH * t} stroke="var(--line)" strokeWidth="1" />
          ))}
          <path d={area} fill="url(#effGrad)" />
          <path d={line} fill="none" stroke="var(--accent)" strokeWidth="2" />
          {efforts.map((v, i) => (
            <circle key={i} cx={x(i)} cy={y(v)} r={i === bestI ? 4 : 2.4} fill={i === bestI ? "var(--accent)" : "var(--panel)"} stroke="var(--accent)" strokeWidth="1.5" />
          ))}
          {[0, 0.5, 1].map((t, k) => (
            <text key={k} x={padL - 6} y={padT + innerH * t + 3} textAnchor="end" fontSize="9" fontFamily="var(--mono)" fill="var(--faint)">{fmtSecs(Math.round(lo + (hi - lo) * t))}</text>
          ))}
          {hover != null && (
            <g>
              <line x1={x(hover)} x2={x(hover)} y1={padT} y2={padT + innerH} stroke="var(--line-3)" strokeWidth="1" />
              <circle cx={x(hover)} cy={y(efforts[hover])} r="4" fill="var(--accent)" stroke="var(--bg)" strokeWidth="1.5" />
            </g>
          )}
        </svg>
      )}
      {hover != null && (
        <div style={{ position: "absolute", top: 4, left: Math.min(Math.max(x(hover) - 36, 2), w - 80),
          background: "var(--panel-3)", border: "1px solid var(--line-2)", borderRadius: 7, padding: "5px 9px",
          fontFamily: "var(--mono)", fontSize: 11, color: "var(--accent)", fontWeight: 600, pointerEvents: "none" }}>
          {fmtSecs(efforts[hover])}{efforts[hover] === best && " · PR"}
        </div>
      )}
    </div>
  );
}

Object.assign(window, { SegmentsScreen });
