/* RUNIQLO — shared UI components. Babel/JSX. Exports to window. */

const R = window.RUNIQLO;

/* ---------- formatting helpers ---------- */
const fmtDate = (d, opts) => d.toLocaleDateString("en-US", opts || { month: "short", day: "numeric" });
const fmtWeekday = (d) => d.toLocaleDateString("en-US", { weekday: "short" }).toUpperCase();
const daysBetween = (a, b) => Math.round((b - a) / 86400000);
function relTime(d) {
  const mins = Math.round((R.TODAY - d) / 60000);
  if (mins < 60) return mins + "m ago";
  const h = Math.round(mins / 60);
  if (h < 24) return h + "h ago";
  const days = Math.round(h / 24);
  if (days === 1) return "yesterday";
  if (days < 7) return days + "d ago";
  return fmtDate(d);
}
const signed = (n) => (n > 0 ? "+" : "") + n;

/* form/TSB descriptor */
function formState(tsb) {
  if (tsb >= 25) return { label: "PEAKED", color: "var(--accent)", note: "Race-ready freshness" };
  if (tsb >= 8) return { label: "FRESH", color: "var(--fresh)", note: "Primed for quality" };
  if (tsb > -12) return { label: "NEUTRAL", color: "var(--neutral)", note: "Productive training zone" };
  if (tsb > -25) return { label: "FATIGUED", color: "var(--fatigue)", note: "Carrying load — ease back" };
  return { label: "STRAINED", color: "var(--fatigue)", note: "High risk — recover" };
}

/* workout type config */
const WORKOUT = {
  long:      { color: "var(--z2)", label: "LONG" },
  threshold: { color: "var(--z4)", label: "THRESHOLD" },
  interval:  { color: "var(--z5)", label: "INTERVAL" },
  easy:      { color: "var(--z1)", label: "EASY" },
  rest:      { color: "var(--faint)", label: "REST" },
};
const ZONEKEY = { 0: "var(--faint)", 1: "var(--z1)", 2: "var(--z2)", 3: "var(--z3)", 4: "var(--z4)", 5: "var(--z5)", 6: "var(--z6)" };

/* adherence config */
const ADHERENCE = {
  match:   { color: "var(--fresh)", label: "ON PLAN", dot: "●" },
  partial: { color: "var(--neutral)", label: "PARTIAL", dot: "◐" },
  extra:   { color: "var(--z2)", label: "UNPLANNED", dot: "+" },
  missed:  { color: "var(--fatigue)", label: "MISSED", dot: "○" },
};

/* ---------- Icons (thin line) ---------- */
function Icon({ name, size = 18, stroke = 1.6 }) {
  const p = {
    dash: "M3 12.5h6l2-7 3 14 2-7h6",
    activity: "M4 6h16M4 12h16M4 18h10",
    route: "M6 19a2 2 0 100-4 2 2 0 000 4zM18 9a2 2 0 100-4 2 2 0 000 4zM7 17c6 0 4-10 10-10",
    coach: "M5 5h14v10H9l-4 4z",
    segment: "M4 17l5-5 4 3 7-8",
    user: "M12 12a4 4 0 100-8 4 4 0 000 8zM4.5 20a7.5 7.5 0 0115 0",
    gear: "M12 15a3 3 0 100-6 3 3 0 000 6zM12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1",
    bolt: "M13 2L4 14h7l-1 8 9-12h-7z",
    clock: "M12 21a9 9 0 100-18 9 9 0 000 18zM12 7v5l3 2",
    map: "M9 4L3 6v14l6-2 6 2 6-2V4l-6 2-6-2z M9 4v14 M15 6v14",
    heart: "M12 20s-7-4.5-7-10a4 4 0 017-2 4 4 0 017 2c0 5.5-7 10-7 10z",
    arrow: "M5 12h14M13 6l6 6-6 6",
    chevron: "M9 6l6 6-6 6",
    target: "M12 21a9 9 0 100-18 9 9 0 000 18zM12 16a4 4 0 100-8 4 4 0 000 8zM12 12h.01",
    send: "M4 12l16-7-7 16-2-7-7-2z",
    check: "M5 12l4 4 10-11",
    wind: "M3 8h11a2.5 2.5 0 10-2.5-2.5M3 16h15a2.5 2.5 0 11-2.5 2.5M3 12h9",
    plus: "M12 5v14M5 12h14",
    calendar: "M4 6h16v15H4zM4 10h16M8 3v4M16 3v4",
  }[name];
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
      strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round" style={{ display: "block", flexShrink: 0 }}>
      <path d={p} />
    </svg>
  );
}

/* ---------- Nav rail ---------- */
function NavRail({ route, onNav }) {
  const items = [
    { id: "dash", icon: "dash", label: "Briefing" },
    { id: "activities", icon: "activity", label: "Activities" },
    { id: "coach", icon: "coach", label: "Coach" },
    { id: "segments", icon: "segment", label: "Segments" },
    { id: "profile", icon: "user", label: "Profile" },
  ];
  return (
    <nav style={{ width: "var(--rail-w)", background: "var(--bg-2)", borderRight: "1px solid var(--line)",
      display: "flex", flexDirection: "column", alignItems: "center", padding: "14px 0", flexShrink: 0, gap: 4 }}>
      <div style={{ width: 34, height: 34, borderRadius: 8, background: "var(--accent)", display: "grid", placeItems: "center",
        marginBottom: 18, boxShadow: "0 0 16px var(--accent-glow)" }}>
        <span style={{ fontFamily: "var(--mono)", fontWeight: 700, fontSize: 16, color: "var(--accent-ink)" }}>R</span>
      </div>
      {items.map((it) => {
        const active = route.screen === it.id;
        return (
          <button key={it.id} onClick={() => !it.soon && onNav({ screen: it.id })} title={it.label + (it.soon ? " (soon)" : "")}
            style={{ width: 44, height: 44, borderRadius: 9, border: "1px solid " + (active ? "var(--line-2)" : "transparent"),
              background: active ? "var(--panel-2)" : "transparent", color: active ? "var(--accent)" : it.soon ? "var(--faintest)" : "var(--dim)",
              cursor: it.soon ? "not-allowed" : "pointer", display: "grid", placeItems: "center", position: "relative", transition: "all .15s" }}
            onMouseEnter={(e) => { if (!active && !it.soon) e.currentTarget.style.color = "var(--text)"; }}
            onMouseLeave={(e) => { if (!active && !it.soon) e.currentTarget.style.color = "var(--dim)"; }}>
            <Icon name={it.icon} size={19} />
            {active && <span style={{ position: "absolute", left: -1, top: 11, bottom: 11, width: 2, background: "var(--accent)", borderRadius: 2 }} />}
          </button>
        );
      })}
      <div style={{ flex: 1 }} />
      <button title="Settings" onClick={() => onNav({ screen: "profile" })} style={{ width: 44, height: 44, borderRadius: 9, border: "1px solid transparent", background: "transparent",
        color: "var(--faint)", cursor: "pointer", display: "grid", placeItems: "center" }}>
        <Icon name="gear" size={18} />
      </button>
    </nav>
  );
}

/* ---------- Status bar (top) ---------- */
function StatusBar({ title, sub, right }) {
  const a = R.athlete;
  const daysToRace = daysBetween(R.TODAY, a.goal.date);
  return (
    <header style={{ height: 52, borderBottom: "1px solid var(--line)", display: "flex", alignItems: "center",
      padding: "0 22px", gap: 18, flexShrink: 0, background: "var(--bg)" }}>
      <div style={{ display: "flex", flexDirection: "column", minWidth: 0 }}>
        <div style={{ fontSize: 15, fontWeight: 600, letterSpacing: "-0.01em", lineHeight: 1.1 }}>{title}</div>
        {sub && <div className="lbl" style={{ marginTop: 2 }}>{sub}</div>}
      </div>
      <div style={{ flex: 1 }} />
      {right}
      <div style={{ display: "flex", alignItems: "center", gap: 7, padding: "5px 11px", border: "1px solid var(--line)", borderRadius: 7 }}>
        <span className="live-dot" />
        <span className="mono" style={{ fontSize: 10.5, color: "var(--dim)", letterSpacing: ".04em" }}>STRAVA · SYNCED {relTime(R.activities[0].date).toUpperCase()}</span>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 9, paddingLeft: 16, borderLeft: "1px solid var(--line)" }}>
        <Icon name="target" size={15} stroke={1.5} />
        <div style={{ display: "flex", flexDirection: "column", lineHeight: 1.25 }}>
          <span className="num" style={{ fontSize: 12, color: "var(--text)", fontWeight: 600 }}>{daysToRace} days <span style={{ color: "var(--faint)", fontWeight: 500 }}>to {a.goal.title}</span></span>
          <span className="lbl" style={{ marginTop: 2 }}>{a.goal.target} · {fmtDate(a.goal.date)}</span>
        </div>
      </div>
      <div style={{ width: 30, height: 30, borderRadius: "50%", background: "var(--panel-3)", border: "1px solid var(--line-2)",
        display: "grid", placeItems: "center", fontFamily: "var(--mono)", fontSize: 11, color: "var(--text)", fontWeight: 600 }}>SR</div>
    </header>
  );
}

/* ---------- Tile (panel w/ header) ---------- */
function Tile({ title, right, children, pad = true, ticks = false, style, className = "", bodyStyle }) {
  return (
    <section className={"panel " + (ticks ? "ticks " : "") + className} style={style}>
      {title && (
        <div className="panel-hd">
          <span className="lbl">{title}</span>
          {right}
        </div>
      )}
      <div style={{ padding: pad ? "var(--pad)" : 0, ...bodyStyle }}>{children}</div>
    </section>
  );
}

/* ---------- Readout (big metric) ---------- */
function Readout({ value, unit, label, color = "var(--text)", sub, size = "var(--fs-hero)", trend }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
      {label && <span className="lbl">{label}</span>}
      <div style={{ display: "flex", alignItems: "baseline", gap: 5 }}>
        <span className="num" style={{ fontSize: size, fontWeight: 600, color, lineHeight: 1, letterSpacing: "-0.03em" }}>{value}</span>
        {unit && <span className="mono" style={{ fontSize: "var(--fs-sm)", color: "var(--faint)" }}>{unit}</span>}
        {trend != null && (
          <span className="mono" style={{ fontSize: 11, color: trend >= 0 ? "var(--fresh)" : "var(--fatigue)", marginLeft: 2 }}>
            {trend >= 0 ? "▲" : "▼"}{Math.abs(trend)}
          </span>
        )}
      </div>
      {sub && <span style={{ fontSize: 11.5, color: "var(--dim)" }}>{sub}</span>}
    </div>
  );
}

/* ---------- Tag / badge ---------- */
function Tag({ children, color, style, filled }) {
  return (
    <span className="tag" style={{ color: filled ? "var(--accent-ink)" : (color || "var(--dim)"),
      background: filled ? color : "transparent", borderColor: color ? color : "var(--line-2)",
      ...(color && !filled ? { borderColor: "color-mix(in srgb, " + color + " 45%, transparent)" } : {}), ...style }}>
      {children}
    </span>
  );
}

function AdherenceBadge({ a }) {
  const cfg = ADHERENCE[a] || ADHERENCE.match;
  return (
    <span className="tag" style={{ color: cfg.color, borderColor: "color-mix(in srgb, " + cfg.color + " 40%, transparent)" }}>
      <span style={{ fontSize: 9 }}>{cfg.dot}</span>{cfg.label}
    </span>
  );
}

function WorkoutDot({ type, size = 8 }) {
  const c = (WORKOUT[type] || WORKOUT.easy).color;
  return <span style={{ width: size, height: size, borderRadius: "50%", background: c, flexShrink: 0, display: "inline-block" }} />;
}

/* ---------- mini activity row ---------- */
function ActivityRow({ act, onClick, compact }) {
  const wk = WORKOUT[act.type] || WORKOUT.easy;
  return (
    <button onClick={onClick} style={{ display: "grid", gridTemplateColumns: compact ? "auto 1fr auto" : "auto 1fr auto auto",
      alignItems: "center", gap: 14, width: "100%", textAlign: "left", background: "transparent", border: "none",
      borderBottom: "1px solid var(--line)", padding: "11px 4px", cursor: "pointer", color: "inherit", transition: "background .12s" }}
      onMouseEnter={(e) => e.currentTarget.style.background = "var(--panel-2)"}
      onMouseLeave={(e) => e.currentTarget.style.background = "transparent"}>
      <span style={{ width: 30, height: 30, borderRadius: 7, border: "1px solid " + wk.color, display: "grid", placeItems: "center",
        background: "color-mix(in srgb, " + wk.color + " 12%, transparent)" }}>
        <WorkoutDot type={act.type} size={9} />
      </span>
      <div style={{ minWidth: 0 }}>
        <div style={{ fontSize: 13, fontWeight: 500, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{act.name}</div>
        <div className="lbl" style={{ marginTop: 2 }}>{fmtDate(act.date)} · {wk.label}</div>
      </div>
      {!compact && (
        <div style={{ display: "flex", gap: 16, alignItems: "center" }}>
          <Mini v={act.dist.toFixed(1)} u="km" />
          <Mini v={act.pace} u="/km" />
          <Mini v={act.avgHr} u="bpm" />
        </div>
      )}
      <AdherenceBadge a={act.adherence} />
    </button>
  );
}
function Mini({ v, u }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end" }}>
      <span className="num" style={{ fontSize: 14, fontWeight: 600 }}>{v}</span>
      <span className="lbl" style={{ fontSize: 8.5 }}>{u}</span>
    </div>
  );
}

Object.assign(window, {
  R, fmtDate, fmtWeekday, daysBetween, relTime, signed, formState, WORKOUT, ZONEKEY, ADHERENCE,
  Icon, NavRail, StatusBar, Tile, Readout, Tag, AdherenceBadge, WorkoutDot, ActivityRow, Mini,
});
