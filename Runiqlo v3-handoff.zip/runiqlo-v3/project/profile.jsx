/* RUNIQLO — Profile & Settings. Babel/JSX. Exports to window. */

function ProfileScreen({ onNav }) {
  const a = window.R.athlete;
  const [zones, setZones] = useState(a.zones);
  const [model, setModel] = useState("RNQ-Coach 2.0");
  const f = window.R.todayFitness;

  const stats = [
    { label: "VO2 MAX", value: a.vo2max, unit: "ml/kg", color: "var(--accent)" },
    { label: "RESTING HR", value: a.restingHr, unit: "bpm" },
    { label: "MAX HR", value: a.maxHr, unit: "bpm" },
    { label: "THRESHOLD HR", value: a.thresholdHr, unit: "bpm" },
    { label: "WEIGHT", value: a.weightKg, unit: "kg" },
    { label: "FITNESS · CTL", value: Math.round(f.ctl), unit: "", color: "var(--accent)" },
  ];

  return (
    <div className="rise" style={{ display: "grid", gridTemplateColumns: "minmax(0,1.5fr) minmax(300px,1fr)", gap: "var(--gap)", alignItems: "start" }}>
      {/* left */}
      <div style={{ display: "flex", flexDirection: "column", gap: "var(--gap)" }}>
        {/* identity */}
        <Tile pad>
          <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
            <div style={{ width: 72, height: 72, borderRadius: "50%", background: "linear-gradient(145deg, var(--panel-3), var(--panel-2))",
              border: "1px solid var(--line-2)", display: "grid", placeItems: "center", fontSize: 26, fontWeight: 650, flexShrink: 0 }}>SR</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: "var(--fs-xl)", fontWeight: 680, letterSpacing: "-0.02em" }}>{a.name}</div>
              <div className="lbl" style={{ marginTop: 4 }}>{a.callsign} · {a.location.toUpperCase()} · AGE {a.age}</div>
              <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
                <Tag color="var(--fresh)"><span className="live-dot" style={{ width: 6, height: 6 }} /> STRAVA CONNECTED</Tag>
                <Tag>{window.R.macroPlan.phases.find(p => p.state === "active").name} PHASE</Tag>
              </div>
            </div>
          </div>
        </Tile>

        {/* stats grid */}
        <Tile title="Physiology" right={<button className="btn btn-ghost" style={{ padding: "4px 10px" }}>Edit</button>}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 1, background: "var(--line)", border: "1px solid var(--line)", borderRadius: "var(--radius-sm)", overflow: "hidden" }}>
            {stats.map((s, i) => (
              <div key={i} style={{ background: "var(--panel)", padding: "15px 16px" }}>
                <div className="lbl" style={{ fontSize: 8.5 }}>{s.label}</div>
                <div style={{ display: "flex", alignItems: "baseline", gap: 4, marginTop: 5 }}>
                  <span className="num" style={{ fontSize: 24, fontWeight: 650, color: s.color || "var(--text)", letterSpacing: "-0.03em" }}>{s.value}</span>
                  {s.unit && <span className="mono" style={{ fontSize: 10, color: "var(--faint)" }}>{s.unit}</span>}
                </div>
              </div>
            ))}
          </div>
        </Tile>

        {/* HR zone editor */}
        <Tile title="Heart-Rate Zones" right={<span className="lbl">6-ZONE MODEL · MAX {a.maxHr}</span>}>
          <ZoneEditor zones={zones} setZones={setZones} maxHr={a.maxHr} />
        </Tile>
      </div>

      {/* right — settings */}
      <div style={{ display: "flex", flexDirection: "column", gap: "var(--gap)" }}>
        <Tile title="Goal" ticks right={<Tag color="var(--accent)">{window.daysBetween(window.R.TODAY, a.goal.date)}D</Tag>}>
          <div style={{ fontSize: "var(--fs-lg)", fontWeight: 650 }}>{a.goal.title}</div>
          <div className="lbl" style={{ marginTop: 3 }}>{fmtDate(a.goal.date, { weekday: "long", month: "long", day: "numeric" }).toUpperCase()}</div>
          <div style={{ display: "flex", gap: 10, marginTop: 14 }}>
            <div style={{ flex: 1, padding: "11px 13px", background: "var(--panel-2)", border: "1px solid var(--line)", borderRadius: "var(--radius-sm)" }}>
              <div className="lbl" style={{ fontSize: 8.5 }}>TARGET</div>
              <div className="num" style={{ fontSize: 20, fontWeight: 650, color: "var(--accent)", marginTop: 3 }}>{a.goal.target}</div>
            </div>
            <button className="btn" style={{ alignSelf: "stretch" }} onClick={() => onNav({ screen: "coach" })}><Icon name="coach" size={14} /> Revise with coach</button>
          </div>
        </Tile>

        <Tile title="Strava Connection">
          <div style={{ display: "flex", alignItems: "center", gap: 13, padding: "11px 13px", background: "var(--panel-2)", border: "1px solid var(--line)", borderRadius: "var(--radius-sm)" }}>
            <div style={{ width: 38, height: 38, borderRadius: 9, background: "#FC4C02", display: "grid", placeItems: "center", flexShrink: 0 }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="#fff"><path d="M13.8 2L7 14.5h3.9L13.8 9l2.9 5.5h3.9zM13.8 14.5l-1.95 3.75L9.9 14.5H7l4.85 9 4.85-9z"/></svg>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13.5, fontWeight: 590 }}>Strava</div>
              <div className="lbl" style={{ marginTop: 2 }}>SYNCED {window.relTime(window.R.activities[0].date).toUpperCase()} · AUTO</div>
            </div>
            <Tag color="var(--fresh)">ACTIVE</Tag>
          </div>
          <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
            <button className="btn" style={{ flex: 1, justifyContent: "center" }}>Sync now</button>
            <button className="btn btn-ghost" style={{ flex: 1, justifyContent: "center" }}>Disconnect</button>
          </div>
        </Tile>

        <Tile title="AI Coach">
          <div className="lbl" style={{ marginBottom: 8 }}>MODEL</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
            {[
              { id: "RNQ-Coach 2.0", desc: "Directive · adaptive periodization", badge: "RECOMMENDED" },
              { id: "RNQ-Coach Lite", desc: "Faster · lighter reasoning", badge: null },
              { id: "Analyst", desc: "Surfaces insight, you decide", badge: null },
            ].map((m) => {
              const sel = model === m.id;
              return (
                <button key={m.id} onClick={() => setModel(m.id)} style={{ display: "flex", alignItems: "center", gap: 11, padding: "11px 13px",
                  borderRadius: "var(--radius-sm)", border: "1px solid " + (sel ? "color-mix(in srgb, var(--accent) 55%, transparent)" : "var(--line)"),
                  background: sel ? "color-mix(in srgb, var(--accent) 8%, var(--panel))" : "var(--panel-2)", cursor: "pointer", textAlign: "left", color: "inherit" }}>
                  <span style={{ width: 16, height: 16, borderRadius: "50%", border: "2px solid " + (sel ? "var(--accent)" : "var(--line-3)"),
                    display: "grid", placeItems: "center", flexShrink: 0 }}>
                    {sel && <span style={{ width: 7, height: 7, borderRadius: "50%", background: "var(--accent)" }} />}
                  </span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13, fontWeight: 590, display: "flex", alignItems: "center", gap: 7 }}>{m.id}{m.badge && <span className="tag" style={{ color: "var(--accent)", borderColor: "color-mix(in srgb, var(--accent) 40%, transparent)", padding: "1px 7px" }}>{m.badge}</span>}</div>
                    <div className="lbl" style={{ marginTop: 2, fontSize: 9 }}>{m.desc}</div>
                  </div>
                </button>
              );
            })}
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 14, paddingTop: 14, borderTop: "1px solid var(--line)" }}>
            <div>
              <div style={{ fontSize: 12.5, fontWeight: 590 }}>Proactive nudges</div>
              <div className="lbl" style={{ marginTop: 2, fontSize: 9 }}>COACH MESSAGES BEFORE KEY SESSIONS</div>
            </div>
            <Toggle on />
          </div>
        </Tile>
      </div>
    </div>
  );
}

function Toggle({ on: initial }) {
  const [on, setOn] = useState(initial);
  return (
    <button onClick={() => setOn(!on)} style={{ width: 44, height: 26, borderRadius: 980, border: "none", cursor: "pointer",
      background: on ? "var(--fresh)" : "var(--panel-3)", padding: 3, transition: "background .2s", display: "flex", justifyContent: on ? "flex-end" : "flex-start" }}>
      <span style={{ width: 20, height: 20, borderRadius: "50%", background: "#fff", boxShadow: "0 1px 3px rgba(0,0,0,0.3)", transition: "all .2s" }} />
    </button>
  );
}

function ZoneEditor({ zones, setZones, maxHr }) {
  const [drag, setDrag] = useState(null);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      {/* visual band */}
      <div style={{ display: "flex", height: 18, borderRadius: 6, overflow: "hidden", border: "1px solid var(--line)" }}>
        {zones.map((z, i) => {
          const next = zones[i + 1];
          const width = ((next ? next.lo : maxHr) - z.lo) / maxHr * 100;
          return <div key={i} style={{ width: width + "%", background: z.color, opacity: 0.9 }} title={z.name} />;
        })}
      </div>
      {/* rows */}
      <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
        {zones.map((z, i) => {
          const next = zones[i + 1];
          const hi = next ? next.lo - 1 : maxHr;
          return (
            <div key={i} style={{ display: "grid", gridTemplateColumns: "auto 1fr auto auto", alignItems: "center", gap: 12,
              padding: "8px 11px", background: "var(--panel-2)", border: "1px solid var(--line)", borderRadius: "var(--radius-sm)" }}>
              <span style={{ width: 10, height: 10, borderRadius: 3, background: z.color }} />
              <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
                <span className="mono" style={{ fontSize: 11, color: "var(--dim)", width: 20 }}>Z{z.z}</span>
                <span className="lbl">{z.name}</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <Stepper value={z.lo} onChange={(v) => { const nz = [...zones]; nz[i] = { ...z, lo: v }; setZones(nz); }} disabled={i === 0} />
                <span className="mono" style={{ fontSize: 11, color: "var(--faint)" }}>–</span>
                <span className="num" style={{ fontSize: 13, fontWeight: 600, width: 34, textAlign: "right" }}>{hi}</span>
                <span className="mono" style={{ fontSize: 10, color: "var(--faint)" }}>bpm</span>
              </div>
              <span className="num" style={{ fontSize: 12, color: "var(--dim)", width: 50, textAlign: "right" }}>{Math.round(z.lo / maxHr * 100)}–{Math.round(hi / maxHr * 100)}%</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function Stepper({ value, onChange, disabled }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 0, border: "1px solid var(--line-2)", borderRadius: 8, overflow: "hidden", opacity: disabled ? 0.4 : 1 }}>
      <button disabled={disabled} onClick={() => onChange(value - 1)} style={{ width: 22, height: 26, border: "none", background: "var(--panel-3)", color: "var(--text)", cursor: disabled ? "default" : "pointer", fontSize: 14 }}>−</button>
      <span className="num" style={{ fontSize: 13, fontWeight: 600, width: 34, textAlign: "center" }}>{value}</span>
      <button disabled={disabled} onClick={() => onChange(value + 1)} style={{ width: 22, height: 26, border: "none", background: "var(--panel-3)", color: "var(--text)", cursor: disabled ? "default" : "pointer", fontSize: 14 }}>+</button>
    </div>
  );
}

Object.assign(window, { ProfileScreen });
