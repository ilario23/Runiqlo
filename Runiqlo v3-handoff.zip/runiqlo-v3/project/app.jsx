/* RUNIQLO — App shell, routing, tweaks, mount. Babel/JSX. */

const ACCENTS = {
  lime:   { accent: "#C6F833", accent2: "#A6D420", glow: "rgba(198,248,51,0.18)", ink: "#0A0D11" },
  amber:  { accent: "#F2A33C", accent2: "#D9871F", glow: "rgba(242,163,60,0.18)", ink: "#0A0D11" },
  cyan:   { accent: "#3FD6E0", accent2: "#1FB4BE", glow: "rgba(63,214,224,0.18)", ink: "#06181A" },
  coral:  { accent: "#FF6B5A", accent2: "#E64C3B", glow: "rgba(255,107,90,0.18)", ink: "#1A0A08" },
};

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "dark",
  "density": "compact",
  "accent": "lime",
  "gauge": "dial"
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [route, setRoute] = useState({ screen: "dash" });

  useEffect(() => {
    document.documentElement.setAttribute("data-density", t.density);
  }, [t.density]);
  useEffect(() => {
    document.documentElement.setAttribute("data-theme", t.theme);
  }, [t.theme]);
  useEffect(() => {
    window.__gauge = t.gauge;
    // bump a state to force re-render of gauges
    setRoute((r) => ({ ...r }));
  }, [t.gauge]);
  useEffect(() => {
    const a = ACCENTS[t.accent] || ACCENTS.lime;
    const r = document.documentElement.style;
    r.setProperty("--accent", a.accent);
    r.setProperty("--accent-2", a.accent2);
    r.setProperty("--accent-glow", a.glow);
    r.setProperty("--accent-ink", a.ink);
  }, [t.accent]);

  const onNav = (r) => setRoute(r);
  const onOpenActivity = (id) => setRoute({ screen: "activities", activityId: id });

  const titles = {
    dash: { title: "Briefing", sub: "DASHBOARD" },
    activities: { title: route.activityId ? "Activity Analysis" : "Activities", sub: route.activityId ? "DETAIL" : "LOG · TRAILING 28 DAYS" },
    coach: { title: "Coach", sub: "AI TRAINING DIRECTOR" },
    segments: { title: route.segmentId ? "Segment" : "Segments", sub: route.segmentId ? "EFFORT HISTORY" : "AGGREGATED EFFORTS" },
    profile: { title: "Profile", sub: "ATHLETE · SETTINGS" },
  };
  const meta = titles[route.screen] || titles.dash;
  const scrollable = route.screen !== "coach";

  return (
    <div style={{ display: "flex", height: "100vh", overflow: "hidden" }}>
      <NavRail route={route} onNav={onNav} />
      <div style={{ flex: 1, display: "flex", flexDirection: "column", minWidth: 0 }}>
        <StatusBar title={meta.title} sub={meta.sub} />
        <main className={scrollable ? "scroll" : ""} style={{ flex: 1, minHeight: 0, padding: "var(--pad)",
          display: "flex", flexDirection: "column", overflow: scrollable ? "auto" : "hidden" }}>
          {route.screen === "dash" && <Dashboard onNav={onNav} onOpenActivity={onOpenActivity} />}
          {route.screen === "activities" && <ActivitiesScreen route={route} onNav={onNav} onOpenActivity={onOpenActivity} />}
          {route.screen === "coach" && <CoachScreen onNav={onNav} onOpenActivity={onOpenActivity} />}
          {route.screen === "segments" && <SegmentsScreen route={route} onNav={onNav} />}
          {route.screen === "profile" && <ProfileScreen onNav={onNav} />}
        </main>
      </div>

      <TweaksPanel>
        <TweakSection label="Appearance" />
        <TweakRadio label="Theme" value={t.theme} options={["dark", "light"]} onChange={(v) => setTweak("theme", v)} />
        <TweakRadio label="Density" value={t.density} options={["compact", "roomy"]} onChange={(v) => setTweak("density", v)} />
        <TweakSection label="Form gauge" />
        <TweakRadio label="Style" value={t.gauge} options={["dial", "ring"]} onChange={(v) => setTweak("gauge", v)} />
        <TweakSection label="Signal accent" />
        <TweakColor label="Accent" value={ACCENTS[t.accent].accent}
          options={Object.values(ACCENTS).map((a) => a.accent)}
          onChange={(hex) => {
            const key = Object.keys(ACCENTS).find((k) => ACCENTS[k].accent === hex) || "lime";
            setTweak("accent", key);
          }} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
