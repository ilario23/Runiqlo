/* RUNIQLO — Coach plan panel (goal → macro → week). Babel/JSX. Exports to window. */

function PlanPanel({ onNav }) {
  const mp = window.R.macroPlan;
  const a = window.R.athlete;
  const daysToRace = window.daysBetween(window.R.TODAY, a.goal.date);
  const weekPct = Math.round((mp.currentWeek / mp.totalWeeks) * 100);
  return (
    <React.Fragment>
      {/* goal */}
      <Tile title="Goal" ticks right={<Tag color="var(--accent)">{daysToRace}D OUT</Tag>}>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <div>
            <div style={{ fontSize: "var(--fs-lg)", fontWeight: 600, letterSpacing: "-0.01em" }}>{a.goal.title}</div>
            <div className="lbl" style={{ marginTop: 3 }}>{fmtDate(a.goal.date, { weekday: "short", month: "long", day: "numeric", year: "numeric" }).toUpperCase()}</div>
          </div>
          <div style={{ display: "flex", gap: 1, background: "var(--line)", border: "1px solid var(--line)", borderRadius: 8, overflow: "hidden" }}>
            {[["TARGET", a.goal.target], ["CURRENT CTL", Math.round(window.R.todayFitness.ctl)], ["VO2 MAX", a.vo2max]].map(([k, v], i) => (
              <div key={i} style={{ flex: 1, background: "var(--panel)", padding: "10px 11px" }}>
                <div className="lbl" style={{ fontSize: 8 }}>{k}</div>
                <div className="num" style={{ fontSize: 15, fontWeight: 600, marginTop: 3 }}>{v}</div>
              </div>
            ))}
          </div>
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
              <span className="lbl">PLAN PROGRESS</span>
              <span className="mono" style={{ fontSize: 10.5, color: "var(--dim)" }}>WK {mp.currentWeek}/{mp.totalWeeks}</span>
            </div>
            <div style={{ height: 6, background: "var(--panel-3)", borderRadius: 4, overflow: "hidden", border: "1px solid var(--line)" }}>
              <div style={{ width: weekPct + "%", height: "100%", background: "var(--accent)", boxShadow: "0 0 10px var(--accent-glow)" }} />
            </div>
          </div>
        </div>
      </Tile>

      {/* macro plan */}
      <Tile title="Macro Plan" right={<span className="lbl">4 PHASES</span>}>
        <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 14 }}>
          {mp.phases.map((p, i) => {
            const c = p.state === "active" ? "var(--accent)" : p.state === "done" ? "var(--fresh)" : "var(--faint)";
            return (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 11, padding: "9px 11px", borderRadius: 8,
                border: "1px solid " + (p.state === "active" ? "var(--line-2)" : "var(--line)"),
                background: p.state === "active" ? "color-mix(in srgb, var(--accent) 7%, var(--panel))" : "var(--panel)" }}>
                <span style={{ width: 8, height: 8, borderRadius: "50%", background: c, flexShrink: 0,
                  boxShadow: p.state === "active" ? "0 0 8px var(--accent-glow)" : "none" }} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", alignItems: "baseline", gap: 7 }}>
                    <span className="mono" style={{ fontSize: 12, fontWeight: 600, color: p.state === "upcoming" ? "var(--dim)" : "var(--text)" }}>{p.name}</span>
                    <span className="lbl" style={{ fontSize: 8.5 }}>WK {p.weeks}</span>
                  </div>
                  <div style={{ fontSize: 10.5, color: "var(--faint)", marginTop: 1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{p.focus}</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div className="num" style={{ fontSize: 12, fontWeight: 600, color: c }}>{p.volume}</div>
                  <div className="lbl" style={{ fontSize: 7.5 }}>KM/WK</div>
                </div>
              </div>
            );
          })}
        </div>
        <div className="lbl" style={{ marginBottom: 8 }}>WEEKLY VOLUME · KM</div>
        <VolumeBars data={mp.volumeByWeek} current={mp.currentWeek} height={86} />
      </Tile>

      {/* this week */}
      <Tile title="This Week" right={
        <button className="btn btn-ghost" style={{ padding: "4px 8px" }} onClick={() => onNav({ screen: "dash" })}>
          <Icon name="calendar" size={13} /> Full
        </button>
      }>
        <div style={{ display: "flex", flexDirection: "column" }}>
          {window.R.plannedWeek.map((d, i) => {
            const isToday = d.status === "today";
            const isPast = d.date < window.R.TODAY && !isToday;
            const c = window.ZONEKEY[d.zone];
            return (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 11, padding: "9px 2px",
                borderBottom: i < 6 ? "1px solid var(--line)" : "none", opacity: d.label === "REST" ? 0.6 : 1 }}>
                <span className="lbl" style={{ width: 26, color: isToday ? "var(--accent)" : "var(--faint)" }}>{d.dow}</span>
                <span style={{ width: 8, height: 8, borderRadius: "50%", background: c, flexShrink: 0 }} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="mono" style={{ fontSize: 11.5, fontWeight: 600, color: isToday ? "var(--accent)" : "var(--text)" }}>{d.label}</div>
                  <div style={{ fontSize: 9.5, color: "var(--faint)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{d.detail}</div>
                </div>
                {d.dist > 0 && <span className="num" style={{ fontSize: 12, fontWeight: 600 }}>{d.dist}<span className="lbl" style={{ fontSize: 7.5 }}>km</span></span>}
                {isPast ? <Icon name="check" size={13} stroke={2} /> : isToday ? <span className="live-dot" /> : <span style={{ width: 13 }} />}
              </div>
            );
          })}
        </div>
      </Tile>
    </React.Fragment>
  );
}

Object.assign(window, { PlanPanel });
