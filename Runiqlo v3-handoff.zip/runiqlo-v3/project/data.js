/* RUNIQLO — mock data layer. Attaches window.RUNIQLO. Plain JS (no JSX). */
(function () {
  "use strict";

  // ---- seeded RNG so routes/series are stable across reloads ----
  function mulberry32(a) {
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  const DAY = 86400000;
  const TODAY = new Date(2026, 5, 8); // Jun 8 2026 (Mon)
  TODAY.setHours(7, 0, 0, 0);

  // ---------- Athlete ----------
  const athlete = {
    name: "Sam Rourke",
    callsign: "RNQ-01",
    location: "Boulder, CO",
    age: 31,
    weightKg: 68,
    maxHr: 191,
    restingHr: 46,
    thresholdHr: 172,
    vo2max: 61,
    sinceDays: 4,
    goal: {
      title: "Berlin Marathon",
      target: "Sub-2:59:00",
      date: new Date(2026, 8, 20), // Sep 20
      weeksOut: 15,
    },
    zones: [
      { z: 1, name: "RECOVERY", lo: 0,   hi: 124, color: "#5B6B7A" },
      { z: 2, name: "ENDURANCE", lo: 124, hi: 143, color: "#2E7CF6" },
      { z: 3, name: "TEMPO",     lo: 143, hi: 158, color: "#21C08B" },
      { z: 4, name: "THRESHOLD", lo: 158, hi: 172, color: "#E8B931" },
      { z: 5, name: "VO2 MAX",   lo: 172, hi: 184, color: "#F2762E" },
      { z: 6, name: "ANAEROBIC", lo: 184, hi: 210, color: "#E4453A" },
    ],
  };

  // ---------- Fitness time-series (CTL / ATL / TSB) ----------
  // 98 days back -> today. Daily TSS loads, then exponentially-weighted CTL(42d)/ATL(7d).
  const rnd = mulberry32(20260608);
  const N = 98;
  const series = [];
  // pass 1: raw daily training loads
  const loads = [];
  for (let i = N - 1; i >= 0; i--) {
    const date = new Date(TODAY.getTime() - i * DAY);
    const dow = date.getDay(); // 0 Sun .. 6 Sat
    let load = 0;
    const progress = (N - i) / N;        // ramp fitness over the block
    const rampVol = 0.72 + progress * 0.7;
    if (dow === 1) load = 62;        // Mon quality
    else if (dow === 2) load = 50;   // Tue easy
    else if (dow === 3) load = 88;   // Wed threshold/vo2
    else if (dow === 4) load = 44;   // Thu easy
    else if (dow === 5) load = 34;   // Fri shakeout
    else if (dow === 6) load = 132;  // Sat long run
    else load = 0;                   // Sun rest
    const weekIdx = Math.floor((N - i) / 7);
    if (weekIdx % 4 === 3) load *= 0.6;  // periodic recovery week
    load *= rampVol * (0.85 + rnd() * 0.3);
    // most recent 9 days = cutback / recovery week -> athlete is FRESH today
    if (i <= 8) load *= (0.30 + 0.06 * i);
    if (i === 0) load = 0;               // today not trained yet
    loads.push({ date, load });
  }
  // pass 2: EWMA -> CTL(42d fitness) / ATL(7d fatigue) / TSB(form)
  let ctl = 40, atl = 40;
  loads.forEach(({ date, load }) => {
    ctl = ctl + (load - ctl) * (1 - Math.exp(-1 / 42));
    atl = atl + (load - atl) * (1 - Math.exp(-1 / 7));
    series.push({
      date,
      tss: Math.round(load),
      ctl: +ctl.toFixed(1),
      atl: +atl.toFixed(1),
      tsb: +(ctl - atl).toFixed(1),
    });
  });
  const todayFitness = series[series.length - 1];

  // ---------- Route trace generator (stylized GPS polyline in 0..100 box) ----------
  function makeRoute(seed, points, loop) {
    const r = mulberry32(seed);
    let x = 18 + r() * 12, y = 50 + (r() - 0.5) * 20;
    let ang = r() * Math.PI * 2;
    const pts = [[x, y]];
    for (let i = 0; i < points; i++) {
      ang += (r() - 0.5) * 1.1;
      const step = 2.2 + r() * 3.2;
      x += Math.cos(ang) * step;
      y += Math.sin(ang) * step;
      // soft bounds reflect
      if (x < 8) { x = 8; ang = Math.PI - ang; }
      if (x > 92) { x = 92; ang = Math.PI - ang; }
      if (y < 12) { y = 12; ang = -ang; }
      if (y > 88) { y = 88; ang = -ang; }
      pts.push([+x.toFixed(2), +y.toFixed(2)]);
    }
    if (loop) pts.push(pts[0]);
    return pts;
  }
  function routePath(pts) {
    return pts.map((p, i) => (i === 0 ? "M" : "L") + p[0] + " " + p[1]).join(" ");
  }

  // ---------- HR + pace streams for a run (for activity detail) ----------
  function makeStreams(seed, durationMin, type) {
    const r = mulberry32(seed);
    const n = Math.max(40, Math.round(durationMin)); // ~1 sample/min
    const hr = [], pace = [], elev = [];
    let baseHr = type === "long" ? 148 : type === "threshold" ? 165 : type === "interval" ? 160 : 138;
    let e = 1640 + r() * 40;
    for (let i = 0; i < n; i++) {
      const t = i / n;
      let target = baseHr;
      if (type === "threshold") target = i < n * 0.18 ? 132 + i * 2 : 168 + Math.sin(i * 0.4) * 4;
      else if (type === "interval") {
        const rep = Math.floor(i / (n / 6));
        target = rep % 2 === 0 ? 178 + (r() - 0.5) * 6 : 132 + (r() - 0.5) * 6;
      } else if (type === "long") target = 142 + t * 14 + Math.sin(i * 0.2) * 3;
      else target = 130 + Math.sin(i * 0.15) * 6 + t * 6;
      const h = Math.max(105, Math.min(192, target + (r() - 0.5) * 6));
      hr.push(Math.round(h));
      // pace seconds/km inversely tied to HR
      const p = 360 - (h - 130) * 1.5 + (r() - 0.5) * 10;
      pace.push(Math.round(Math.max(180, Math.min(420, p))));
      e += (r() - 0.5) * 14;
      elev.push(Math.round(e));
    }
    return { hr, pace, elev };
  }

  function zoneBreakdown(streams, zones) {
    const counts = [0, 0, 0, 0, 0, 0];
    streams.hr.forEach((h) => {
      let zi = 0;
      for (let k = 0; k < zones.length; k++) if (h >= zones[k].lo) zi = k;
      counts[zi]++;
    });
    const total = streams.hr.length;
    return counts.map((c) => +(c / total).toFixed(3));
  }

  function fmtPace(secPerKm) {
    const m = Math.floor(secPerKm / 60), s = Math.round(secPerKm % 60);
    return m + ":" + String(s).padStart(2, "0");
  }
  function fmtDur(min) {
    const h = Math.floor(min / 60), m = Math.round(min % 60);
    return h > 0 ? h + ":" + String(m).padStart(2, "0") + ":00" : m + ":00";
  }

  // ---------- Activities (most recent first) ----------
  const actSpecs = [
    { dOff: 1, name: "Recovery + Strides",    type: "easy",      dist: 9.4,  dur: 50,  elev: 60,  planned: "EASY · 9 KM",          adh: "match" },
    { dOff: 2, name: "Easy Aerobic",          type: "easy",      dist: 8.0,  dur: 44,  elev: 52,  planned: "EASY · 8 KM · Z2",     adh: "match" },
    { dOff: 3, name: "Cutback Long Run",      type: "long",      dist: 24.0, dur: 110, elev: 240, planned: "LONG · 24 KM · Z2",    adh: "match", title: true },
    { dOff: 4, name: "Easy Shakeout",         type: "easy",      dist: 6.4,  dur: 38,  elev: 32,  planned: "EASY · 6 KM",          adh: "match" },
    { dOff: 5, name: "Threshold — 4×2km",     type: "threshold", dist: 13.0, dur: 60,  elev: 88,  planned: "THRESHOLD · 4×2KM @ Z4", adh: "match" },
    { dOff: 8, name: "Sunday Long Run",       type: "long",      dist: 30.8, dur: 142, elev: 288, planned: "LONG · 30 KM · Z2",    adh: "match" },
    { dOff: 10, name: "VO2 — 6×800m",         type: "interval",  dist: 12.0, dur: 58,  elev: 74,  planned: "VO2 · 6×800M @ Z5",    adh: "partial" },
    { dOff: 11, name: "Easy + Strides",       type: "easy",      dist: 9.2,  dur: 50,  elev: 64,  planned: "EASY · 9 KM",          adh: "match" },
    { dOff: 13, name: "Hill Repeats",         type: "interval",  dist: 11.4, dur: 56,  elev: 214, planned: "HILLS · 8×60S",        adh: "match" },
    { dOff: 14, name: "Easy Aerobic",         type: "easy",      dist: 10.0, dur: 54,  elev: 70,  planned: "EASY · 10 KM · Z2",    adh: "match" },
    { dOff: 16, name: "Marathon-Pace 16km",   type: "threshold", dist: 18.5, dur: 82,  elev: 120, planned: "MP · 16 KM @ 4:10",    adh: "match" },
    { dOff: 17, name: "Recovery Jog",         type: "easy",      dist: 7.0,  dur: 41,  elev: 40,  planned: "EASY · 7 KM",          adh: "match" },
  ];

  const activities = actSpecs.map((s, i) => {
    const date = new Date(TODAY.getTime() - s.dOff * DAY);
    date.setHours(6 + (i % 3), 12, 0, 0);
    const streams = makeStreams(1000 + i * 7, s.dur, s.type);
    const zones = zoneBreakdown(streams, athlete.zones);
    const avgHr = Math.round(streams.hr.reduce((a, b) => a + b, 0) / streams.hr.length);
    const maxHr = Math.max.apply(null, streams.hr);
    const paceSec = Math.round((s.dur * 60) / s.dist);
    const route = makeRoute(7000 + i * 13, 70 + Math.round(s.dist), s.type === "easy");
    // training load from this run's own duration × HR intensity (hrTSS), not the daily series
    const intensity = avgHr / athlete.thresholdHr;
    const tss = Math.round((s.dur / 60) * intensity * intensity * 100);
    return {
      id: "act-" + (i + 1),
      name: s.name,
      type: s.type,
      date,
      dist: s.dist,
      durMin: s.dur,
      paceSec,
      pace: fmtPace(paceSec),
      dur: fmtDur(s.dur),
      elev: s.elev,
      avgHr, maxHr,
      tss,
      zones,
      route, routeD: routePath(route),
      streams,
      planned: s.planned,
      adherence: s.adh, // match | partial | extra | missed
    };
  });

  // ---------- 7-day plan (this week, Mon Jun 8 -> Sun Jun 14) ----------
  // adherence links to completed activities for past days.
  const weekStart = new Date(TODAY); // Mon
  const plannedWeek = [
    { dow: "MON", date: new Date(weekStart.getTime() + 0 * DAY), label: "THRESHOLD", detail: "5 × 2 km @ Z4", dist: 14, durMin: 62, zone: 4, status: "today" },
    { dow: "TUE", date: new Date(weekStart.getTime() + 1 * DAY), label: "EASY",      detail: "Aerobic · Z2",  dist: 10, durMin: 54, zone: 2, status: "upcoming" },
    { dow: "WED", date: new Date(weekStart.getTime() + 2 * DAY), label: "VO2 MAX",   detail: "6 × 800 m @ Z5",dist: 12, durMin: 58, zone: 5, status: "upcoming" },
    { dow: "THU", date: new Date(weekStart.getTime() + 3 * DAY), label: "REST",      detail: "Full recovery", dist: 0,  durMin: 0,  zone: 0, status: "upcoming" },
    { dow: "FRI", date: new Date(weekStart.getTime() + 4 * DAY), label: "EASY",      detail: "Shakeout + strides", dist: 8, durMin: 44, zone: 2, status: "upcoming" },
    { dow: "SAT", date: new Date(weekStart.getTime() + 5 * DAY), label: "LONG RUN",  detail: "34 km · last 8 @ MP", dist: 34, durMin: 156, zone: 2, status: "upcoming" },
    { dow: "SUN", date: new Date(weekStart.getTime() + 6 * DAY), label: "REST",      detail: "Mobility only",  dist: 0,  durMin: 0,  zone: 0, status: "upcoming" },
  ];
  const weekTargetKm = plannedWeek.reduce((a, d) => a + d.dist, 0);

  // ---------- Macro plan (phases) ----------
  const macroPlan = {
    goal: athlete.goal,
    currentWeek: 9,
    totalWeeks: 15,
    phases: [
      { name: "BASE",  weeks: "1–5",   volume: "70–90", focus: "Aerobic volume, durability", state: "done" },
      { name: "BUILD", weeks: "6–11",  volume: "90–115", focus: "Threshold & VO2, marathon pace", state: "active" },
      { name: "PEAK",  weeks: "12–13", volume: "100–110", focus: "Race-specific sharpening", state: "upcoming" },
      { name: "TAPER", weeks: "14–15", volume: "55→30", focus: "Freshness, race rehearsal", state: "upcoming" },
    ],
    volumeByWeek: [72, 78, 84, 62, 90, 96, 104, 78, 108, 112, 100, 106, 88, 56, 32],
  };

  // ---------- Coach session ----------
  const coachSessions = [
    { id: "cs-1", title: "Berlin build — week 9", date: new Date(TODAY.getTime() - 0 * DAY), active: true },
    { id: "cs-2", title: "Recalibrating after calf niggle", date: new Date(TODAY.getTime() - 6 * DAY) },
    { id: "cs-3", title: "Goal set: Berlin sub-3", date: new Date(TODAY.getTime() - 58 * DAY) },
    { id: "cs-4", title: "Onboarding & baseline", date: new Date(TODAY.getTime() - 72 * DAY) },
  ];

  const coachThread = [
    { role: "coach", time: "07:02", text: "Morning, Sam. Your form is deep in the green — the freshest you've been in two weeks after last week's cutback. We don't waste a window like this on easy miles.", tool: null },
    { role: "coach", time: "07:02", text: "Today is the week's anchor session: **5 × 2 km @ threshold (Z4, 4:08–4:14/km)**, 90 s float between. Total 14 km. This is the workout that moves your lactate threshold toward Berlin pace.", tool: "session" },
    { role: "coach", time: "07:02", text: "Conditions are in your favour.", tool: "weather" },
    { role: "athlete", time: "07:05", text: "Legs feel good. Should I push the reps closer to 4:05 since I'm fresh?" },
    { role: "coach", time: "07:06", text: "No. Discipline beats heroics. Hold 4:08–4:14 — the goal is repeatable threshold, not a time trial. If rep 5 feels easy at that pace, *that's* the win. Save the aggression for Saturday's marathon-pace finish." },
  ];

  // ---------- Segments ----------
  const segments = [
    { id: "seg-1", name: "Boulder Creek Path — Mile Loop", dist: 1609, grade: 0.4, attempts: 41, pr: "5:12", prDate: new Date(2026, 4, 30), trend: "up",   efforts: [332, 328, 330, 322, 319, 320, 315, 318, 312, 314, 312] },
    { id: "seg-2", name: "Flagstaff Climb — Lower",        dist: 2380, grade: 6.1, attempts: 18, pr: "11:48", prDate: new Date(2026, 3, 18), trend: "flat", efforts: [742, 738, 730, 728, 726, 720, 712, 715, 708, 710] },
    { id: "seg-3", name: "Reservoir Out-and-Back",         dist: 4830, grade: 0.8, attempts: 27, pr: "17:31", prDate: new Date(2026, 5, 1), trend: "up",   efforts: [1132, 1120, 1108, 1095, 1088, 1072, 1064, 1058, 1051] },
    { id: "seg-4", name: "Bobolink Sprint",                dist: 402,  grade: -0.3, attempts: 63, pr: "1:08", prDate: new Date(2026, 2, 12), trend: "flat", efforts: [72, 71, 70, 70, 69, 71, 70, 68, 69, 68] },
    { id: "seg-5", name: "Mesa Trail Tempo",               dist: 3200, grade: 2.4, attempts: 14, pr: "13:02", prDate: new Date(2026, 5, 3), trend: "up",   efforts: [842, 836, 828, 820, 812, 805, 798, 790, 782] },
    { id: "seg-6", name: "Canyon Mouth Strides",           dist: 805,  grade: -1.1, attempts: 35, pr: "2:34", prDate: new Date(2026, 1, 28), trend: "down", efforts: [150, 152, 151, 154, 153, 155, 156, 154, 157] },
  ];
  segments.forEach((s) => {
    s.route = makeRoute(9000 + s.dist, 40, false);
    s.routeD = routePath(s.route);
  });

  // ---------- Zone distribution (trailing 28d) ----------
  const zoneDist28 = [0.18, 0.46, 0.12, 0.14, 0.07, 0.03]; // fraction of time

  window.RUNIQLO = {
    athlete, series, todayFitness, activities, plannedWeek, weekStart, weekTargetKm,
    macroPlan, coachSessions, coachThread, segments, zoneDist28, TODAY,
    helpers: { fmtPace, fmtDur, routePath, makeRoute },
  };
})();
