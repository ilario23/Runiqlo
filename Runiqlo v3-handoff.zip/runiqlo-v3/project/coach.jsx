/* RUNIQLO — AI Coach: chat + plan overview + week. Babel/JSX. Exports to window. */

function boldParse(text) {
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return parts.map((p, i) =>
    p.startsWith("**") ? <strong key={i} style={{ color: "var(--text)", fontWeight: 600 }}>{p.slice(2, -2)}</strong> : <React.Fragment key={i}>{p}</React.Fragment>
  );
}

function CoachScreen({ onNav, onOpenActivity }) {
  const [thread, setThread] = useState(window.R.coachThread);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const [activeSession, setActiveSession] = useState("cs-1");
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [thread, typing]);

  const send = (txt) => {
    const t = (txt || input).trim();
    if (!t) return;
    setThread((p) => [...p, { role: "athlete", time: "07:0" + (8 + p.length % 2), text: t }]);
    setInput("");
    setTyping(true);
    setTimeout(() => {
      setTyping(false);
      setThread((p) => [...p, {
        role: "coach", time: "07:09",
        text: "Good question. Based on your current load — fitness 62, form +14 — hold the prescribed paces. We'll reassess after Saturday's long run and adjust next week's volume from there.",
      }]);
    }, 1400);
  };

  const prompts = ["How's my fitness trending?", "Can I move the long run to Sunday?", "Why threshold today?"];

  return (
    <div className="rise" style={{ display: "grid", gridTemplateColumns: "220px minmax(0,1fr) 340px", gap: "var(--gap)", height: "100%", minHeight: 0 }}>
      {/* sessions */}
      <Tile title="Sessions" pad={false} style={{ display: "flex", flexDirection: "column", minHeight: 0 }} bodyStyle={{ padding: 0, display: "flex", flexDirection: "column", minHeight: 0, flex: 1 }}>
        <div style={{ padding: "10px" }}>
          <button className="btn btn-accent" style={{ width: "100%", justifyContent: "center" }}><Icon name="plus" size={13} /> New session</button>
        </div>
        <div className="scroll" style={{ flex: 1, minHeight: 0, padding: "0 8px 8px" }}>
          {window.R.coachSessions.map((s) => {
            const active = s.id === activeSession;
            return (
              <button key={s.id} onClick={() => setActiveSession(s.id)} style={{ width: "100%", textAlign: "left", padding: "10px 11px", borderRadius: 8,
                border: "1px solid " + (active ? "var(--line-2)" : "transparent"), background: active ? "var(--panel-2)" : "transparent", cursor: "pointer",
                marginBottom: 4, color: "inherit", display: "flex", flexDirection: "column", gap: 3 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  {s.active && <span className="live-dot" style={{ width: 6, height: 6 }} />}
                  <span style={{ fontSize: 12, fontWeight: active ? 600 : 500, color: active ? "var(--text)" : "var(--dim)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{s.title}</span>
                </div>
                <span className="lbl" style={{ fontSize: 8.5 }}>{window.relTime(s.date).toUpperCase()}</span>
              </button>
            );
          })}
        </div>
        <div style={{ padding: "10px", borderTop: "1px solid var(--line)" }}>
          <div className="lbl" style={{ marginBottom: 6 }}>ATHLETE NOTES</div>
          <div style={{ fontSize: 11, color: "var(--dim)", lineHeight: 1.5 }}>Right calf tightness resolved. Prefers AM sessions. Targeting 2:58 in Berlin.</div>
        </div>
      </Tile>

      {/* chat */}
      <Tile pad={false} style={{ display: "flex", flexDirection: "column", minHeight: 0 }} bodyStyle={{ padding: 0, display: "flex", flexDirection: "column", minHeight: 0, flex: 1 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 11, padding: "13px 16px", borderBottom: "1px solid var(--line)" }}>
          <span style={{ width: 34, height: 34, borderRadius: 9, background: "var(--accent)", color: "var(--accent-ink)", display: "grid", placeItems: "center",
            fontFamily: "var(--mono)", fontWeight: 700, fontSize: 15, boxShadow: "0 0 14px var(--accent-glow)" }}>C</span>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, fontWeight: 600, display: "flex", alignItems: "center", gap: 8 }}>Coach <span className="tag" style={{ color: "var(--fresh)", borderColor: "color-mix(in srgb, var(--fresh) 40%, transparent)" }}>READING FITNESS</span></div>
            <div className="lbl" style={{ marginTop: 2 }}>BERLIN BUILD · WEEK 9 · DIRECTIVE MODE</div>
          </div>
          <button className="btn btn-ghost"><Icon name="gear" size={15} /></button>
        </div>

        <div ref={scrollRef} className="scroll" style={{ flex: 1, minHeight: 0, padding: "18px 16px", display: "flex", flexDirection: "column", gap: 14 }}>
          <div style={{ textAlign: "center" }}><span className="lbl">TODAY · {fmtDate(window.R.TODAY).toUpperCase()}</span></div>
          {thread.map((m, i) => <ChatBubble key={i} m={m} onNav={onNav} />)}
          {typing && (
            <div style={{ display: "flex", gap: 10 }}>
              <CoachAvatar />
              <div style={{ background: "var(--panel-2)", border: "1px solid var(--line)", borderRadius: "4px 12px 12px 12px", padding: "12px 16px", display: "flex", gap: 5 }}>
                {[0, 1, 2].map((d) => <span key={d} className="live-dot" style={{ animationDelay: d * 0.2 + "s" }} />)}
              </div>
            </div>
          )}
        </div>

        <div style={{ padding: "12px 16px", borderTop: "1px solid var(--line)" }}>
          <div style={{ display: "flex", gap: 6, marginBottom: 10, flexWrap: "wrap" }}>
            {prompts.map((p) => (
              <button key={p} onClick={() => send(p)} className="tag" style={{ cursor: "pointer", background: "var(--panel-2)" }}>{p}</button>
            ))}
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "flex-end" }}>
            <textarea value={input} onChange={(e) => setInput(e.target.value)} rows={1}
              onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
              placeholder="Ask your coach, or request a plan change…"
              style={{ flex: 1, resize: "none", background: "var(--panel-2)", border: "1px solid var(--line-2)", borderRadius: 9, padding: "11px 14px",
                color: "var(--text)", fontFamily: "var(--sans)", fontSize: 13, outline: "none", lineHeight: 1.4, maxHeight: 90 }}
              onFocus={(e) => e.target.style.borderColor = "var(--line-3)"} onBlur={(e) => e.target.style.borderColor = "var(--line-2)"} />
            <button className="btn btn-accent" onClick={() => send()} style={{ height: 40 }}><Icon name="send" size={14} /></button>
          </div>
        </div>
      </Tile>

      {/* plan panel */}
      <div className="scroll" style={{ display: "flex", flexDirection: "column", gap: "var(--gap)", minHeight: 0, paddingRight: 2 }}>
        <PlanPanel onNav={onNav} />
      </div>
    </div>
  );
}

function CoachAvatar() {
  return <span style={{ width: 30, height: 30, borderRadius: 8, background: "var(--accent)", color: "var(--accent-ink)", display: "grid", placeItems: "center",
    fontFamily: "var(--mono)", fontWeight: 700, fontSize: 13, flexShrink: 0, alignSelf: "flex-start" }}>C</span>;
}

function ChatBubble({ m, onNav }) {
  const isCoach = m.role === "coach";
  return (
    <div style={{ display: "flex", gap: 10, flexDirection: isCoach ? "row" : "row-reverse" }}>
      {isCoach ? <CoachAvatar /> : <span style={{ width: 30, height: 30, borderRadius: 8, background: "var(--panel-3)", border: "1px solid var(--line-2)",
        display: "grid", placeItems: "center", fontFamily: "var(--mono)", fontWeight: 600, fontSize: 11, flexShrink: 0, alignSelf: "flex-start" }}>SR</span>}
      <div style={{ maxWidth: "78%", display: "flex", flexDirection: "column", gap: 8, alignItems: isCoach ? "flex-start" : "flex-end" }}>
        <div style={{ background: isCoach ? "var(--panel-2)" : "color-mix(in srgb, var(--accent) 12%, var(--panel))",
          border: "1px solid " + (isCoach ? "var(--line)" : "color-mix(in srgb, var(--accent) 30%, transparent)"),
          borderRadius: isCoach ? "4px 12px 12px 12px" : "12px 4px 12px 12px", padding: "11px 15px", fontSize: 13, lineHeight: 1.55, color: "var(--text)", textWrap: "pretty" }}>
          {boldParse(m.text)}
        </div>
        {m.tool === "session" && <SessionToolCard onNav={onNav} />}
        {m.tool === "weather" && <WeatherToolCard />}
        <span className="lbl" style={{ fontSize: 8.5 }}>{m.time}</span>
      </div>
    </div>
  );
}

function SessionToolCard({ onNav }) {
  const s = window.TODAY_SESSION;
  return (
    <div style={{ border: "1px solid var(--line-2)", borderRadius: 10, overflow: "hidden", width: "100%", maxWidth: 380 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 7, padding: "8px 12px", background: "var(--panel-3)", borderBottom: "1px solid var(--line)" }}>
        <Icon name="bolt" size={13} stroke={1.8} /><span className="lbl">TOOL · PLANNED SESSION</span>
      </div>
      <div style={{ padding: "13px 14px", background: "var(--panel-2)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 11 }}>
          <span style={{ fontSize: 15, fontWeight: 600 }}>{s.structure}</span>
          <Tag color={window.WORKOUT[s.type].color}>{window.WORKOUT[s.type].label}</Tag>
        </div>
        <div style={{ display: "flex", gap: 18 }}>
          {[[s.dist.toFixed(0), "km"], ["~" + s.durMin, "min"], [s.paceTarget, "/km"]].map(([v, u], i) => (
            <div key={i}><div className="num" style={{ fontSize: 16, fontWeight: 600 }}>{v}</div><div className="lbl" style={{ fontSize: 8 }}>{u}</div></div>
          ))}
        </div>
      </div>
    </div>
  );
}

function WeatherToolCard() {
  const w = window.TODAY_SESSION.weather;
  return (
    <div style={{ border: "1px solid var(--line-2)", borderRadius: 10, padding: "11px 14px", background: "var(--panel-2)", width: "100%", maxWidth: 380,
      display: "flex", alignItems: "center", gap: 14 }}>
      <Icon name="wind" size={20} stroke={1.5} />
      <div style={{ flex: 1 }}>
        <div className="lbl" style={{ marginBottom: 2 }}>TOOL · WEATHER · {w.window}</div>
        <div style={{ fontSize: 12.5 }}>{w.cond}</div>
      </div>
      <div style={{ textAlign: "right" }}>
        <div className="num" style={{ fontSize: 20, fontWeight: 600 }}>{w.temp}°</div>
        <div className="lbl" style={{ color: "var(--fresh)", fontSize: 8.5 }}>{w.score}</div>
      </div>
    </div>
  );
}

Object.assign(window, { CoachScreen });
