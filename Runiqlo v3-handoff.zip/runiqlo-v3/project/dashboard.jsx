/* RUNIQLO — Dashboard with 3 directions. Babel/JSX. Exports to window. */

const TODAY_SESSION = {
  type: "threshold",
  label: "THRESHOLD INTERVALS",
  structure: "5 × 2 KM @ Z4",
  dist: 14.0,
  durMin: 62,
  paceTarget: "4:08–4:14",
  recovery: "90 s float jog",
  why: "We spend that freshness on the week's anchor session — a threshold block — before Saturday's long run.",
  weather: { temp: 13, wind: 8, cond: "Clear · light NW wind", score: "IDEAL", window: "06:00–08:00" },
};

/* derive the coach's rationale from live form so it never drifts from the gauge */
function todayWhy() {
  const f = window.R.todayFitness;
  const st = window.formState(f.tsb);
  return `You're carrying ${window.signed(Math.round(f.tsb))} form — ${st.label.toLowerCase()}, the freshest you've been in two weeks. ${TODAY_SESSION.why}`;
}

/* ============ shared blocks ============ */

function FormBlock({ big, gauge }) {
  const f = window.R.todayFitness;
  const st = window.formState(f.tsb);
  const gaugeSize = big ? 230 : 168;
  const useRing = (gauge || window.__gauge) === "ring";
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: big ? 10 : 6 }}>
      <div style={{ position: "relative", width: gaugeSize, display: "grid", placeItems: "center" }}>
        {useRing ? <FormRing tsb={f.tsb} size={big ? 200 : 150} /> : <FormGauge tsb={f.tsb} size={gaugeSize} />}
        <div style={{ position: "absolute", left: 0, right: 0, bottom: useRing ? "auto" : (big ? 14 : 7),
          top: useRing ? "50%" : "auto", transform: useRing ? "translateY(-50%)" : "none", textAlign: "center" }}>
          <div className="num" style={{ fontSize: big ? 54 : 38, fontWeight: 680, color: st.color, lineHeight: 1, letterSpacing: "-0.045em" }}>
            {window.signed(f.tsb)}
          </div>
          <div className="lbl" style={{ color: st.color, marginTop: 5, fontSize: big ? 11 : 9.5 }}>{st.label}</div>
        </div>
      </div>
      <div style={{ fontSize: big ? 13 : 11.5, color: "var(--dim)", textAlign: "center" }}>{st.note}</div>
    </div>
  );
}

function FitnessReadouts({ vertical }) {
  const f = window.R.todayFitness;
  const prev = window.R.series[window.R.series.length - 8];
  const items = [
    { label: "FITNESS · CTL", value: Math.round(f.ctl), trend: Math.round(f.ctl - prev.ctl), color: "var(--accent)" },
    { label: "FATIGUE · ATL", value: Math.round(f.atl), trend: Math.round(f.atl - prev.atl), color: "var(--z5)" },
    { label: "FORM · TSB", value: window.signed(Math.round(f.tsb)), trend: null, color: window.formState(f.tsb).color },
  ];
  return (
    <div style={{ display: vertical ? "flex" : "grid", flexDirection: "column",
      gridTemplateColumns: vertical ? undefined : "repeat(3,1fr)", gap: vertical ? 14 : "var(--gap)" }}>
      {items.map((it, i) => (
        <div key={i} style={{ display: "flex", flexDirection: "column", gap: 2, padding: vertical ? "0" : "0" }}>
          <span className="lbl">{it.label}</span>
          <div style={{ display: "flex", alignItems: "baseline", gap: 6 }}>
            <span className="num" style={{ fontSize: "var(--fs-xl)", fontWeight: 600, color: it.color, letterSpacing: "-0.03em" }}>{it.value}</span>
            {it.trend != null && (
              <span className="mono" style={{ fontSize: 10.5, color: it.trend >= 0 ? "var(--fresh)" : "var(--fatigue)" }}>
                {it.trend >= 0 ? "▲" : "▼"} {Math.abs(it.trend)} <span style={{ color: "var(--faint)" }}>7d</span>
              </span>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

/* The prescribed workout for today */
function SessionCard({ session = TODAY_SESSION, onCoach, dense }) {
  const wk = window.WORKOUT[session.type];
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: dense ? 12 : 16 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <span style={{ width: 3, alignSelf: "stretch", background: wk.color, borderRadius: 2 }} />
        <div>
          <div className="lbl" style={{ color: wk.color }}>PRESCRIBED · TODAY</div>
          <div style={{ fontSize: "var(--fs-lg)", fontWeight: 650, letterSpacing: "-0.015em", marginTop: 3, lineHeight: 1.1, whiteSpace: "nowrap" }}>{session.label}</div>
        </div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 1, background: "var(--line)", border: "1px solid var(--line)", borderRadius: "var(--radius-sm)", overflow: "hidden" }}>
        {[
          { k: "STRUCTURE", v: session.structure },
          { k: "DISTANCE", v: session.dist.toFixed(0), u: "km" },
          { k: "DURATION", v: "~" + session.durMin, u: "min" },
          { k: "TARGET PACE", v: session.paceTarget, u: "/km" },
        ].map((m, i) => (
          <div key={i} style={{ background: "var(--panel)", padding: "11px 12px", display: "flex", flexDirection: "column", gap: 4 }}>
            <span className="lbl" style={{ fontSize: 8.5 }}>{m.k}</span>
            <div style={{ display: "flex", alignItems: "baseline", gap: 3 }}>
              <span className="num" style={{ fontSize: m.v.length > 6 ? 14 : 18, fontWeight: 600 }}>{m.v}</span>
              {m.u && <span className="mono" style={{ fontSize: 10, color: "var(--faint)" }}>{m.u}</span>}
            </div>
          </div>
        ))}
      </div>
      <div style={{ display: "flex", gap: 11, alignItems: "flex-start", padding: "14px 16px", background: "var(--panel-2)", borderRadius: "var(--radius-sm)", border: "1px solid var(--line)" }}>
        <span style={{ width: 22, height: 22, borderRadius: 7, background: "var(--accent)", color: "var(--accent-ink)", display: "grid", placeItems: "center", flexShrink: 0, fontWeight: 700, fontSize: 12 }}>C</span>
        <div>
          <div className="lbl" style={{ marginBottom: 3 }}>COACH RATIONALE</div>
          <div style={{ fontSize: 12.5, color: "var(--text)", lineHeight: 1.5 }}>{todayWhy()}</div>
        </div>
      </div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
        <Tag color="var(--fresh)"><Icon name="wind" size={11} stroke={1.8} /> {session.weather.cond}</Tag>
        <Tag color="var(--fresh)">{session.weather.temp}°C · {session.weather.score} WINDOW</Tag>
        <div style={{ flex: 1 }} />
        <button className="btn btn-ghost" onClick={onCoach}>Ask coach <Icon name="arrow" size={13} /></button>
        <button className="btn btn-accent"><Icon name="bolt" size={13} /> Start session</button>
      </div>
    </div>
  );
}

/* 7-day plan strip */
function WeekStrip({ onCoach, compact }) {
  const week = window.R.plannedWeek;
  const acts = window.R.activities;
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(7,1fr)", gap: "var(--gap)" }}>
      {week.map((d, i) => {
        const wk = window.WORKOUT[d.label === "REST" ? "rest" : d.label === "LONG RUN" ? "long" : d.label === "VO2 MAX" ? "interval" : d.label.toLowerCase()] || { color: window.ZONEKEY[d.zone] };
        const isToday = d.status === "today";
        const isPast = d.date < window.R.TODAY && !isToday;
        const done = isPast; // assume past planned days completed for demo
        return (
          <div key={i} style={{ border: "1px solid " + (isToday ? "color-mix(in srgb, var(--accent) 55%, transparent)" : "var(--line)"), borderRadius: "var(--radius-sm)",
            padding: compact ? "11px 10px" : "13px 12px", background: isToday ? "color-mix(in srgb, var(--accent) 9%, var(--panel))" : "var(--panel-2)",
            display: "flex", flexDirection: "column", gap: 7, opacity: d.label === "REST" ? 0.7 : 1, position: "relative", minHeight: compact ? 72 : 92 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span className="lbl" style={{ color: isToday ? "var(--accent)" : "var(--faint)" }}>{d.dow}</span>
              {done && <Icon name="check" size={12} stroke={2} />}
              {isToday && <span className="live-dot" />}
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
              <span style={{ width: 7, height: 7, borderRadius: "50%", background: wk.color, flexShrink: 0 }} />
              <span className="mono" style={{ fontSize: 10.5, fontWeight: 600, letterSpacing: "0.02em" }}>{d.label}</span>
            </div>
            {!compact && <div style={{ fontSize: 10.5, color: "var(--dim)", lineHeight: 1.3 }}>{d.detail}</div>}
            <div style={{ flex: 1 }} />
            {d.dist > 0 && (
              <div style={{ display: "flex", alignItems: "baseline", gap: 3 }}>
                <span className="num" style={{ fontSize: 14, fontWeight: 600 }}>{d.dist}</span>
                <span className="lbl" style={{ fontSize: 8 }}>km</span>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

function LastRunCard({ onOpen, tall }) {
  const a = window.R.activities[0];
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <div>
          <div style={{ fontSize: 14, fontWeight: 600 }}>{a.name}</div>
          <div className="lbl" style={{ marginTop: 2 }}>{window.relTime(a.date)} · {window.WORKOUT[a.type].label}</div>
        </div>
        <AdherenceBadge a={a.adherence} />
      </div>
      <RouteTrace d={a.routeD} height={tall ? 150 : 116} />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 10 }}>
        {[
          { v: a.dist.toFixed(1), u: "km" },
          { v: a.pace, u: "/km" },
          { v: a.avgHr, u: "bpm" },
          { v: a.elev, u: "m ↑" },
        ].map((m, i) => (
          <div key={i} style={{ display: "flex", flexDirection: "column" }}>
            <span className="num" style={{ fontSize: 17, fontWeight: 600 }}>{m.v}</span>
            <span className="lbl" style={{ fontSize: 8.5 }}>{m.u}</span>
          </div>
        ))}
      </div>
      <ZoneStack zones={window.R.athlete.zones} dist={a.zones} showPct={false} height={9} />
      <button className="btn btn-ghost" style={{ alignSelf: "flex-start" }} onClick={onOpen}>Open analysis <Icon name="arrow" size={13} /></button>
    </div>
  );
}

/* ============ DIRECTION 1: INSTRUMENT (dense telemetry) ============ */
function DashInstrument({ onNav, onOpenActivity }) {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "minmax(0,2.1fr) minmax(280px,1fr)", gap: "var(--gap)", alignItems: "start" }}>
      {/* left column */}
      <div style={{ display: "flex", flexDirection: "column", gap: "var(--gap)" }}>
        <Tile title="Today's Session" ticks right={<span className="lbl">{fmtDate(window.R.TODAY, { weekday: "long", month: "short", day: "numeric" })}</span>}>
          <SessionCard onCoach={() => onNav({ screen: "coach" })} dense />
        </Tile>
        <Tile title="Training Load · 90 days" right={<Legend />}>
          <FitnessChart series={window.R.series} days={90} height={216} />
        </Tile>
        <Tile title="This Week" right={<span className="lbl">{window.R.weekTargetKm} KM TARGET</span>}>
          <WeekStrip compact />
        </Tile>
      </div>
      {/* right column */}
      <div style={{ display: "flex", flexDirection: "column", gap: "var(--gap)" }}>
        <Tile title="Today's Form" ticks>
          <FormBlock />
          <hr className="hairline" style={{ margin: "14px 0" }} />
          <FitnessReadouts />
        </Tile>
        <Tile title="Last Run">
          <LastRunCard onOpen={() => onOpenActivity(window.R.activities[0].id)} />
        </Tile>
        <Tile title="Zone Mix · 28d" right={<span className="lbl">PYRAMID</span>}>
          <ZoneBars zones={window.R.athlete.zones} dist={window.R.zoneDist28} height={94} />
        </Tile>
      </div>
    </div>
  );
}

function Legend() {
  return (
    <div style={{ display: "flex", gap: 12 }}>
      {[["FITNESS", "var(--accent)"], ["FATIGUE", "var(--z5)"], ["FORM", "var(--fresh)"]].map(([k, c]) => (
        <div key={k} style={{ display: "flex", alignItems: "center", gap: 5 }}>
          <span style={{ width: 10, height: 2, background: c, borderRadius: 2 }} />
          <span className="lbl">{k}</span>
        </div>
      ))}
    </div>
  );
}

/* ============ Dashboard shell ============ */
function Dashboard({ onNav, onOpenActivity }) {
  return (
    <div className="rise" style={{ display: "flex", flexDirection: "column", gap: "var(--gap)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 14, flexWrap: "wrap" }}>
        <div style={{ display: "flex", flexDirection: "column" }}>
          <h1 style={{ fontSize: "var(--fs-xl)", fontWeight: 600, letterSpacing: "-0.02em" }}>Good morning, {window.R.athlete.name.split(" ")[0]}.</h1>
          <span className="lbl" style={{ marginTop: 3 }}>{window.R.macroPlan.phases.find(p => p.state === "active").name} PHASE · WEEK {window.R.macroPlan.currentWeek} OF {window.R.macroPlan.totalWeeks}</span>
        </div>
        <div style={{ flex: 1 }} />
        <button className="btn btn-accent" onClick={() => onNav({ screen: "coach" })}><Icon name="bolt" size={13} /> Start session</button>
      </div>
      <DashInstrument onNav={onNav} onOpenActivity={onOpenActivity} />
    </div>
  );
}

Object.assign(window, { Dashboard, TODAY_SESSION });
